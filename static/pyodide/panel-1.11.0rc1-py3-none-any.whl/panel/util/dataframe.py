"""
Backend neutral helpers for tabular data.

Panel's data components historically assume pandas. pandas-like frames
(pandas, modin, cuDF) carry a row index which Panel uses to identify
rows across filtering, sorting and editing. Other DataFrame libraries
supported by Narwhals, e.g. Polars and PyArrow, have no such index, so
for those Panel identifies a row by its position in the original frame
and tracks it through filtering and sorting using a temporary row index
column (see `ROW_INDEX`).

Write operations never mutate these frames in place, since some
backends (e.g. PyArrow) are immutable. Instead a new frame is built
and the component's value is replaced.

Narwhals is imported inside the functions to avoid adding to the
import time of Panel.
"""
from __future__ import annotations

import datetime as dt
import typing as t

from collections.abc import Iterable, Mapping, Sequence

import numpy as np

if t.TYPE_CHECKING:
    import narwhals.stable.v2 as nw

ROW_INDEX = '__panel_row_index__'


def has_index(obj: t.Any) -> bool:
    """
    Whether the object is a pandas-like DataFrame, which carries a row
    index that can label rows.
    """
    if obj is None or isinstance(obj, dict):
        return False
    import narwhals.stable.v2.dependencies as nwd
    return nwd.is_pandas_like_dataframe(obj)


def is_dataframe(obj: t.Any) -> bool:
    """
    Whether the object is an eager DataFrame from any library supported
    by Narwhals, e.g. pandas, Polars or PyArrow.
    """
    if obj is None or isinstance(obj, (dict, list, str)):
        return False
    import narwhals.stable.v2.dependencies as nwd
    return nwd.is_into_dataframe(obj)


def is_indexless(obj: t.Any) -> bool:
    """
    Whether the object is a DataFrame without a row index, e.g. a Polars
    DataFrame or a PyArrow Table.
    """
    return is_dataframe(obj) and not has_index(obj)


def to_narwhals(obj: t.Any) -> nw.DataFrame[t.Any]:
    """
    Wraps a native DataFrame in a Narwhals DataFrame without copying.
    """
    import narwhals.stable.v2 as nw
    try:
        return nw.from_native(obj, eager_only=True)
    except TypeError:
        if isinstance(nw.from_native(obj, pass_through=True), nw.LazyFrame):
            raise TypeError(
                f'Lazy frames such as {type(obj).__name__} are not supported, '
                'collect it into an eager DataFrame first.'
            ) from None
        raise


def to_native(df: t.Any) -> t.Any:
    import narwhals.stable.v2 as nw
    return nw.to_native(df) if isinstance(df, nw.DataFrame) else df


def column_names(obj: t.Any) -> list[t.Any]:
    """
    Returns the column names of a dictionary of columns or DataFrame.
    """
    if isinstance(obj, dict):
        return list(obj)
    elif has_index(obj):
        return list(obj.columns)
    return to_narwhals(obj).columns


def copy_data(obj: t.Any) -> t.Any:
    """
    Copies data which may be mutated in place, i.e. dictionaries and
    pandas-like DataFrames. Other DataFrames are never mutated so they
    are returned as is.
    """
    if isinstance(obj, dict) or has_index(obj):
        return obj.copy()
    return obj


def dtype_kind(dtype: nw.dtypes.DType) -> str:
    """
    Maps a Narwhals dtype onto the equivalent NumPy dtype kind.
    """
    import narwhals.stable.v2 as nw
    if dtype == nw.Boolean:
        return 'b'
    elif dtype.is_signed_integer():
        return 'i'
    elif dtype.is_unsigned_integer():
        return 'u'
    elif dtype.is_float() or dtype == nw.Decimal:
        return 'f'
    elif dtype == nw.Datetime or dtype == nw.Date:
        return 'M'
    elif dtype == nw.Duration:
        return 'm'
    elif dtype in (nw.String, nw.Categorical, nw.Enum):
        return 'U'
    return 'O'


def is_date(dtype: nw.dtypes.DType) -> bool:
    import narwhals.stable.v2 as nw
    return dtype == nw.Date


def indexed_column_data(df: t.Any) -> dict[str, np.ndarray]:
    """
    Converts a pandas-like DataFrame into a dictionary of NumPy arrays,
    including a column for its index, which can be sent to a
    ColumnDataSource. Produces the same columns as bokeh's
    `ColumnDataSource.from_df`, without its frame copy and reset_index
    for pandas DataFrames.
    """
    import pandas as pd
    if not isinstance(df, pd.DataFrame):
        from bokeh.models import ColumnDataSource
        return t.cast("dict[str, np.ndarray]", ColumnDataSource.from_df(df))
    columns = df.columns
    if isinstance(columns, pd.MultiIndex):
        try:
            names = ['_'.join(col) for col in columns.values]
        except TypeError:
            raise TypeError('Could not flatten MultiIndex columns. '
                            'use string column names or flatten manually') from None
    else:
        names = columns.tolist()
    index = df.index
    if isinstance(index.name, str):
        index_name = index.name
    else:
        try:
            index_name = '_'.join(t.cast('list[str]', index.names))
        except TypeError:
            index_name = 'index'
    if index_name == 'index' and 'index' in names:
        index_name = 'level_0'
    # Copies keep the ColumnDataSource arrays independent of the frame's
    # storage, which is otherwise mutated in place by edits and patches.
    # tz-aware datetimes are sent as naive UTC datetime64 like bokeh does
    if isinstance(index, pd.DatetimeIndex) and index.tz is not None:
        index_values = index.tz_convert(None).to_numpy(copy=True)
    else:
        index_values = np.array(pd.Index(index.values))
    data = {index_name: index_values}
    for name, (_, col) in zip(names, df.items()):
        if isinstance(col.dtype, pd.DatetimeTZDtype):
            data[name] = col.dt.tz_convert(None).to_numpy(copy=True)
        else:
            data[name] = col.to_numpy(copy=True)
    return data


def add_row_index(obj: t.Any, offset: int = 0) -> t.Any:
    """
    Adds a column recording the position of each row, so rows can be
    tracked through filtering and sorting.
    """
    import narwhals.stable.v2 as nw
    df = to_narwhals(obj).with_row_index(ROW_INDEX)
    if offset:
        df = df.with_columns(nw.col(ROW_INDEX) + offset)
    return df.to_native()


def drop_row_index(obj: t.Any) -> t.Any:
    df = to_narwhals(obj)
    if ROW_INDEX in df.columns:
        df = df.drop(ROW_INDEX)
    return df.to_native()


def row_positions(obj: t.Any) -> list[int]:
    """
    Returns the positions of the rows in the original frame, as
    recorded by `add_row_index`.
    """
    return row_position_array(obj).tolist()


def row_position_array(obj: t.Any) -> np.ndarray:
    return to_narwhals(obj)[ROW_INDEX].to_numpy()


def take_rows(obj: t.Any, rows: Sequence[int] | slice) -> t.Any:
    df = to_narwhals(obj)
    if isinstance(rows, slice):
        return df[rows].to_native()
    return df[list(rows)].to_native()


def row_dict(obj: t.Any, row: int) -> dict[str, t.Any]:
    """
    Returns a row as a dictionary of column name to value, omitting
    the row index column.
    """
    return to_narwhals(drop_row_index(obj))[row:row+1].rows(named=True)[0]


def column_to_numpy(obj: t.Any, column: str) -> np.ndarray:
    array = to_narwhals(obj)[column].to_numpy()
    if array.dtype.kind in 'SU':
        # Fixed width strings would truncate longer values patched in
        array = array.astype(object)
    return array


def to_column_data(obj: t.Any) -> dict[str, np.ndarray]:
    """
    Converts a DataFrame into a dictionary of NumPy arrays, which can
    be sent to a ColumnDataSource.
    """
    df = to_narwhals(obj)
    data = {}
    for col in df.columns:
        if col == ROW_INDEX:
            continue
        data[col] = column_to_numpy(df, col)
    return data


def _to_series(name: str, values: t.Any, dtype: t.Any, backend: t.Any) -> nw.Series[t.Any]:
    import narwhals.stable.v2 as nw
    try:
        return nw.new_series(name, values, dtype, backend=backend)
    except Exception:
        # Values coming from the frontend may not be directly castable,
        # e.g. integer columns with missing values arrive as floats
        # with NaNs.
        values = [
            None if isinstance(v, float) and np.isnan(v) else v
            for v in np.asarray(values).tolist()
        ]
        return nw.new_series(name, values, backend=backend).cast(dtype)


def set_values(obj: t.Any, column: str, rows: Sequence[int] | np.ndarray, values: t.Any) -> t.Any:
    """
    Returns a new frame with the values of the column at the supplied
    row positions replaced.
    """
    import narwhals.stable.v2 as nw
    df = to_narwhals(obj)
    series = df[column]
    positions = np.asarray(rows, dtype=np.int64)
    new = _to_series(column, values, series.dtype, df.implementation)
    if df.implementation.is_pyarrow():
        new = nw.from_native(new.to_native().cast(series.to_native().type), series_only=True).alias(column)
    if not (len(positions) == len(df) and np.array_equal(positions, np.arange(len(df)))):
        new = series.scatter(positions, new)
    return df.with_columns(new).to_native()


def patch_rows(index: int | slice, value: t.Any, nrows: int) -> tuple[list[int], list[t.Any]]:
    """
    Resolves a single (index, value) patch into the row positions it
    applies to and their values, broadcasting scalar slice patches.
    """
    if isinstance(index, slice):
        rows = list(range(*index.indices(nrows)))
        if isinstance(value, (list, tuple, np.ndarray)):
            return rows, list(value)
        return rows, [value] * len(rows)
    index = int(index)
    return [index + nrows if index < 0 else index], [value]


def _restore_arrow_types(frame: t.Any, template: t.Any) -> t.Any:
    """
    Narwhals maps e.g. both string and large_string to a single dtype,
    so a PyArrow table built from narwhals dtypes loses the large types
    of the template and can no longer be concatenated with it.
    """
    import sys
    pa = sys.modules.get('pyarrow')
    if pa is None or not (isinstance(frame, pa.Table) and isinstance(template, pa.Table)):
        return frame
    types = {field.name: field.type for field in template.schema}
    fields = [
        pa.field(field.name, types.get(field.name, field.type), field.nullable)
        for field in frame.schema
    ]
    schema = pa.schema(fields)
    return frame if schema.equals(frame.schema) else frame.cast(schema)


def frame_from_columns(data: Mapping[str, t.Any], template: t.Any) -> t.Any:
    """
    Builds a frame from a dictionary of columns using the backend of
    the template frame.
    """
    import narwhals.stable.v2 as nw
    impl = to_narwhals(template).implementation
    frame = nw.from_dict({str(k): list(v) for k, v in data.items()}, backend=impl).to_native()
    return _restore_arrow_types(frame, template)


def _is_scalar(value: t.Any) -> bool:
    return np.isscalar(value) or value is None or isinstance(value, (dt.date, dt.time, np.datetime64))


def coerce_frame(value: t.Any, template: t.Any) -> t.Any:
    """
    Converts a DataFrame, Series or dictionary of rows or columns into a
    frame of the same backend and schema as the template frame.
    """
    import narwhals.stable.v2 as nw
    tmpl = to_narwhals(template)
    impl = tmpl.implementation
    if hasattr(value, 'to_dict') and not is_dataframe(value) and not isinstance(value, dict):
        # A pandas Series represents a single row
        value = value.to_dict()
    if isinstance(value, Mapping):
        if all(_is_scalar(v) for v in value.values()):
            value = {k: [v] for k, v in value.items()}
        df = nw.from_dict({str(k): list(v) for k, v in value.items()}, backend=impl)
    elif is_dataframe(value):
        df = to_narwhals(value)
        if has_index(value):
            df = to_narwhals(value.reset_index(drop=True))
        if df.implementation != impl:
            df = nw.from_dict(df.to_dict(as_series=False), backend=impl)
    else:
        raise ValueError(
            f"Cannot convert value of type {type(value).__name__} into a "
            "DataFrame, provide a DataFrame or dictionary."
        )
    schema = tmpl.schema
    for col, dtype in schema.items():
        if col not in df.columns:
            continue
        series = df[col]
        if series.dtype == dtype or not (series.dtype.is_numeric() and dtype.is_numeric()):
            continue
        try:
            # PyArrow refuses lossy casts while Polars silently truncates
            lossless = (series.cast(dtype) == series).fill_null(True).all()
        except Exception:
            lossless = False
        if not lossless:
            raise ValueError(
                f"Cannot cast column {col!r} from {series.dtype} to {dtype} "
                "without losing information, ensure the new data matches "
                "the dtypes of the existing data."
            )
    return _restore_arrow_types(df.select([
        nw.col(col).cast(dtype) if col in df.columns else nw.lit(None).cast(dtype).alias(col)
        for col, dtype in schema.items()
    ]).to_native(), template)


def concat_rows(obj: t.Any, other: t.Any, rollover: int | None = None) -> t.Any:
    import narwhals.stable.v2 as nw
    df = nw.concat([to_narwhals(obj), to_narwhals(other)], how='vertical')
    if rollover is not None:
        df = df.tail(rollover)
    return df.to_native()


def _filter_value(value: t.Any, dtype: nw.dtypes.DType) -> t.Any:
    kind = dtype_kind(dtype)
    if isinstance(value, (list, tuple, set, np.ndarray)) or value is None:
        return value
    elif kind in 'iufb':
        return {'i': int, 'u': int, 'f': float, 'b': bool}[kind](value)
    elif kind != 'M':
        return value
    if isinstance(value, str):
        value = dt.datetime.fromisoformat(value)
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        # Tabulator sends datetimes as milliseconds since the epoch
        value = dt.datetime(1970, 1, 1) + dt.timedelta(milliseconds=value)
    if is_date(dtype) and isinstance(value, dt.datetime):
        value = value.date()
    return value


def filter_expr(column: str, value: t.Any) -> nw.Expr | None:
    """
    Returns an expression filtering a column by a value, where the value
    is a scalar (equality), a list or set (membership) or a tuple
    (inclusive range). Returns None if the value does not filter.
    """
    import narwhals.stable.v2 as nw
    col = nw.col(column)
    if value is None:
        return None
    elif np.isscalar(value):
        return col == value
    elif isinstance(value, (list, set)):
        return col.is_in(list(value)) if value else None
    elif isinstance(value, tuple):
        start, end = value
        if start is None and end is None:
            return None
        elif start is None:
            return col <= end
        elif end is None:
            return col >= start
        return (col >= start) & (col <= end)
    raise ValueError(f"'{column} filter value not "
                     "understood. Must be either a scalar, "
                     "tuple or list.")


def header_filter_exprs(
    obj: t.Any, filters: Iterable[Mapping[str, t.Any]],
    filter_defs: Mapping[str, t.Any] | None = None
) -> list[nw.Expr]:
    """
    Returns expressions implementing Tabulator header filter
    specifications, each declaring a 'field', 'type' and 'value'.
    The frame is only used to look up the column dtypes.
    """
    import narwhals.stable.v2 as nw
    schema = nw.from_native(obj).collect_schema()
    filter_defs = filter_defs or {}
    exprs = []
    for filt in filters:
        col_name = filt['field']
        op = filt['type']
        val = filt['value']
        if col_name not in schema:
            continue

        # Sometimes Tabulator will provide a zero/single element list
        if isinstance(val, list):
            if len(val) == 1:
                val = val[0]
            elif not val:
                continue

        col = nw.col(col_name)
        if op not in ('like', 'starts', 'ends', 'keywords', 'regex'):
            val = _filter_value(val, schema[col_name])
        text = col.cast(nw.String).str.to_lowercase()
        if op == '=':
            expr = col == val
        elif op == '!=':
            expr = col != val
        elif op == '<':
            expr = col < val
        elif op == '>':
            expr = col > val
        elif op == '>=':
            expr = col >= val
        elif op == '<=':
            expr = col <= val
        elif op == 'in':
            if not isinstance(val, (list, np.ndarray)):
                val = [val]
            expr = col.is_in(list(val))
        elif op == 'like':
            expr = text.str.contains(str(val).lower(), literal=True)
        elif op == 'starts':
            expr = text.str.starts_with(str(val).lower())
        elif op == 'ends':
            expr = text.str.ends_with(str(val).lower())
        elif op == 'keywords':
            match_all = filter_defs.get(col_name, {}).get('matchAll', False)
            sep = filter_defs.get(col_name, {}).get('separator', ' ')
            matches = [
                text.str.contains(match.lower(), literal=True)
                for match in str(val).split(sep)
            ]
            if match_all:
                exprs.extend(matches)
                continue
            expr = matches[0]
            for match in matches[1:]:
                expr = expr | match
        elif op == 'regex':
            raise ValueError("Regex filtering not supported.")
        else:
            raise ValueError(f"Filter type {op!r} not recognized.")
        exprs.append(expr)
    return exprs


def all_of(exprs: Sequence[nw.Expr]) -> nw.Expr:
    """
    Combines filter expressions, treating missing values as not
    matching the filter.
    """
    expr = exprs[0].fill_null(False)
    for other in exprs[1:]:
        expr = expr & other.fill_null(False)
    return expr


def evaluate_mask(obj: t.Any, expr: nw.Expr) -> np.ndarray:
    """
    Evaluates a filter expression on a frame into a boolean mask.
    """
    return to_narwhals(obj).select(expr.alias('_mask'))['_mask'].to_numpy().astype(bool)


def sort_frame(obj: t.Any, fields: Sequence[str], ascending: Sequence[bool]) -> t.Any:
    """
    Sorts a frame mirroring the sorting algorithm of Tabulator, i.e.
    strings are compared case-insensitively with missing strings
    treated as empty, other missing values are placed last and ties
    keep their original order, like Tabulator's numeric `_index`
    tie-breaker.
    """
    import narwhals.stable.v2 as nw
    df = to_narwhals(obj)
    keys, exprs, descending = [], [], []
    for i, (field, asc) in enumerate(zip(fields, ascending, strict=True)):
        if field not in df.columns:
            continue
        kind = dtype_kind(df.schema[field])
        expr = nw.col(field)
        if kind == 'U':
            expr = expr.cast(nw.String).fill_null('').str.to_lowercase()
        elif kind == 'f':
            expr = expr.fill_nan(None)
        key = f'_sort_{i}_'
        keys.append(key)
        exprs.append(expr.alias(key))
        descending.append(not asc)
    if not keys:
        return df.to_native()
    tie = '_sort_tie_'
    sorted_df = (
        df.with_row_index(tie)
        .with_columns(*exprs)
        .sort([*keys, tie], descending=[*descending, False], nulls_last=True)
        .drop([*keys, tie])
    )
    return sorted_df.to_native()


__all__ = (
    "ROW_INDEX",
    "add_row_index",
    "column_names",
    "column_to_numpy",
    "concat_rows",
    "copy_data",
    "drop_row_index",
    "dtype_kind",
    "all_of",
    "evaluate_mask",
    "filter_expr",
    "frame_from_columns",
    "has_index",
    "header_filter_exprs",
    "indexed_column_data",
    "is_dataframe",
    "is_date",
    "is_indexless",
    "row_dict",
    "row_positions",
    "set_values",
    "sort_frame",
    "take_rows",
    "to_column_data",
    "to_narwhals",
    "to_native",
)
