import asyncio
# Imported for its side effect: the exit hook that disables thread pools must
# be registered before ours so that ours runs first
import concurrent.futures.thread  # noqa: F401
import logging
import threading
import typing as t
import weakref

from tornado.ioloop import IOLoop

from .state import state

logger = logging.getLogger(__name__)

_SHUTDOWN_TIMEOUT = 5


_exit_hook_registered = False
_started_threads: weakref.WeakSet['StoppableThread'] = weakref.WeakSet()


def _join_threads_at_exit() -> None:
    while threads := [thread for thread in list(_started_threads) if thread.is_alive()]:
        for thread in threads:
            thread.join()


def _register_exit_hook() -> None:
    """
    Keep thread pools usable for as long as a StoppableThread is serving.

    When the main thread finishes, Python first disables all thread pools
    and only then waits for the remaining threads, so a server that keeps
    running in a thread could no longer hand off any work. Waiting for the
    server threads in a hook that runs before the pools are disabled avoids
    that. Such hooks run in reverse order of registration.
    """
    global _exit_hook_registered
    if _exit_hook_registered:
        return
    try:
        threading._register_atexit(_join_threads_at_exit)  # type: ignore[attr-defined]
    except (AttributeError, RuntimeError):
        # No such hook, or the interpreter is already shutting down
        return
    _exit_hook_registered = True


class StoppableThread(threading.Thread):
    """Thread class with a stop() method."""

    def __init__(self, io_loop, owns_loop: bool = False, **kwargs):
        super().__init__(**kwargs)
        # Backward compatibility to handle Tornado IOLoop
        if hasattr(io_loop, 'asyncio_loop'):
            io_loop = io_loop.asyncio_loop
        self.asyncio_loop = io_loop
        self._owns_loop = owns_loop
        self.server_id = kwargs.get('kwargs', {}).get('server_id')
        self._shutdown_task: t.Any | None = None

    def start(self) -> None:
        _register_exit_hook()
        _started_threads.add(self)
        super().start()

    def run(self) -> None:
        if hasattr(self, '_target'):
            target, args, kwargs = self._target, self._args, self._kwargs # type: ignore
        else:
            target, args, kwargs = self._Thread__target, self._Thread__args, self._Thread__kwargs # type: ignore
        if not target:
            return
        bokeh_server = None
        try:
            bokeh_server = target(*args, **kwargs)
        finally:
            if (
                bokeh_server is not None and hasattr(bokeh_server, 'stop')
                and not getattr(bokeh_server, '_stopped', False)
            ):
                # Handle tornado server
                try:
                    bokeh_server.stop()
                except Exception:
                    pass
            if self._owns_loop and self.asyncio_loop and not self.asyncio_loop.is_closed():
                try:
                    self._cancel_pending_tasks()
                except Exception:
                    logger.debug('Could not drain pending tasks', exc_info=True)
                try:
                    self._close_loop()
                except Exception:
                    logger.debug('Could not close the event loop', exc_info=True)
            if hasattr(self, '_target'):
                del self._target, self._args, self._kwargs # type: ignore
            else:
                del self._Thread__target, self._Thread__args, self._Thread__kwargs # type: ignore

    def _close_loop(self) -> None:
        # Tornado adds a selector thread and socket pair to a Proactor loop
        io_loop = getattr(IOLoop, '_ioloop_for_asyncio', {}).get(self.asyncio_loop)
        if io_loop is None:
            self.asyncio_loop.close()
        else:
            io_loop.close()

    def _cancel_pending_tasks(self) -> None:
        # Stopping the server can leave tasks pending.
        loop = self.asyncio_loop
        tasks = [task for task in asyncio.all_tasks(loop) if not task.done()]
        if not tasks:
            return
        for task in tasks:
            task.cancel()
        # A task may shield itself from the cancellation.
        loop.run_until_complete(asyncio.wait(tasks, timeout=_SHUTDOWN_TIMEOUT))

    def stop(self) -> None:
        if not self.is_alive():
            return
        elif self.server_id and self.server_id in state._servers:
            server, _, _ = state._servers[self.server_id]
            if hasattr(server, 'should_exit'):
                server.should_exit = True
                self.join()
                return
        if self._shutdown_task:
            raise RuntimeError("Thread already stopping")
        self._shutdown_task = asyncio.run_coroutine_threadsafe(self._shutdown(), self.asyncio_loop)
        self.join()

    async def _shutdown(self):
        # Cancelling a locked callback halfway leaves its coroutine unawaited.
        servers = state._servers.get(self.server_id) if self.server_id else None
        server = servers[0] if servers else None
        if server is not None and not getattr(server, '_stopped', True):
            # Lifecycle hooks may never complete.
            try:
                await asyncio.wait_for(server.stop_async(), _SHUTDOWN_TIMEOUT)
            except TimeoutError:
                logger.warning('Server did not stop within %s seconds', _SHUTDOWN_TIMEOUT)
            except Exception:
                logger.debug('Could not stop the server', exc_info=True)
        cur_task = asyncio.current_task()
        tasks = [t for t in asyncio.all_tasks() if t is not cur_task]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.asyncio_loop.stop()
        self._shutdown_task = None
