"""
Defines the Location  widget which allows changing the href of the window.
"""
from __future__ import annotations

import json
import typing as t
import urllib.parse as urlparse

import param

from ..models.location import Location as _BkLocation
from ..reactive import Syncable
from ..util import edit_readonly, isIn as is_in, parse_query
from .cache import is_equal
from .document import create_doc_if_none_exists
from .proxy import normalize_root_path
from .resources import LOCAL_DIST
from .state import state

if t.TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from bokeh.document import Document
    from bokeh.model import Model
    from bokeh.server.contexts import BokehSessionContext
    from pyviz_comms import Comm

def _get_location_params(protocol: str|None, host: str| None, uri: str| None)->dict:
    params = {}
    href = ''
    if protocol:
        params['protocol'] = href = f'{protocol}:'
    if host:
        if host.startswith('::ffff:'):
            host = host.replace('::ffff:', '')
        elif host == '::1':
            host = host.replace('::1', 'localhost')

        href += f'//{host}'
        if ':' in host:
            params['hostname'], params['port'] = host.split(':')
        else:
            params['hostname'] = host
    if uri:
        search = fragment = None

        if uri.startswith("https,"):
            uri = uri.replace("https,", "")

        if uri.startswith("http"):
            parsed = urlparse.urlparse(uri)
            uri = parsed.path
            search = parsed.query
            fragment = parsed.fragment

        href += uri
        if '?' in uri and '#' in uri:
            params['pathname'], query = uri.split('?')
            search, hash = query.split('#')
        elif '?' in uri:
            params['pathname'], search = uri.split('?')
        elif '#' in uri:
            params['pathname'], fragment = uri.split('#')
        else:
            params['pathname'] = uri
        if search:
            params['search'] = f'?{search}'
        if fragment:
            params['hash'] = f'#{fragment}'
    params['href'] = href
    return params

class Location(Syncable):
    """
    The Location component can be made available in a server context
    to provide read and write access to the URL components in the
    browser.
    """

    href = param.String(readonly=True, doc="""
        The full url, e.g. 'https://localhost:80?color=blue#interact'""")

    hostname = param.String(readonly=True, doc="""
        hostname in window.location e.g. 'panel.holoviz.org'""")

    pathname = param.String(regex=r"^$|[\/]|srcdoc$", doc="""
        pathname in window.location e.g. '/user_guide/Interact.html'""")

    protocol = param.String(readonly=True, doc="""
        protocol in window.location e.g. 'http:' or 'https:'""")

    port = param.String(readonly=True, doc="""
        port in window.location e.g. '80'""")

    search = param.String(regex=r"^$|\?", doc="""
        search in window.location e.g. '?color=blue'""")

    hash = param.String(regex=r"^$|#", doc="""
        hash in window.location e.g. '#interact'""")

    reload = param.Boolean(default=False, doc="""
        Reload the page when the location is updated. For multipage
        apps this should be set to True, For single page apps this
        should be set to False""")

    # Mapping from parameter name to bokeh model property name
    _rename: t.ClassVar[Mapping[str, str | None]] = {"name": None}

    @classmethod
    def from_request(cls, request):
        try:
            from bokeh.server.contexts import _RequestProxy
            if not isinstance(request, _RequestProxy) or request._request is None:
                return cls()
        except ImportError:
            return cls()

        params = _get_location_params(request.protocol, request.host, request.uri)
        loc = cls()
        with edit_readonly(loc):
            loc.param.update(params)
        return loc

    def __init__(self, **params):
        super().__init__(**params)
        self._synced = []
        self._syncing = False
        # The pathname and rel_path depth of the page as it was loaded
        self._anchor: tuple[int, int] | None = None
        self.param.watch(self._update_synced, ['search'])
        self.param.watch(self._sync_pathname, ['pathname'])

    def _get_model(
        self, doc: Document, root: Model | None = None,
        parent: Model | None = None, comm: Comm | None = None
    ) -> Model:
        model = _BkLocation(**self._process_param_change(self._init_params()))
        root = root or model
        self._models[root.ref['id']] = (model, parent)
        self._link_props(model, self._linked_properties, doc, root, comm)
        return model

    @staticmethod
    def _pathname_depth(pathname: str) -> int:
        """
        The number of directories a page relative url has to climb from
        the pathname to reach the root it is served under.
        """
        return max(pathname.count('/') - 1, 0)

    def _sync_pathname(self, event: param.parameterized.Event):
        """
        When in a server context and the pathname is overridden dynamically
        we need to keep the state.rel_path and the Document dist_url template
        variable in sync to ensure that resources are resolved relative to the new URL.
        Additionally we clear the stylesheets cache which holds now outdated URLs.
        """
        doc = state.curdoc
        if doc is None or not (doc.session_context and doc.session_context.server_context):
            return
        # Only a page relative path, as set up for a server session, can
        # follow the pathname, not e.g. the absolute url of an autoload script.
        rel_parts = [part for part in (state.rel_path or '').split('/') if part]
        if any(part != '..' for part in rel_parts):
            return
        # The initial pathname, whether taken from the request or reported
        # by the frontend once it has rendered (e.g. including the prefix
        # of a proxy the server never sees), is the page rel_path was
        # computed for, not a navigation. Depths are taken relative to it,
        # so they do not depend on the prefix the app is served under.
        if 'pathname' in self._param__private.syncing:
            rel_depth = len(rel_parts) if self._anchor is None else self._anchor[1]
            self._anchor = (self._pathname_depth(event.new), rel_depth)
            return
        elif not event.old:
            return
        if self._anchor is None:
            # Until the frontend reports it, the pathname is the one the
            # server received, which lacks the root path of a proxy.
            old = event.old
            root = normalize_root_path(state._base_url)
            if root and old != root and not old.startswith(f'{root}/'):
                old = f'{root}{old}'
            self._anchor = (self._pathname_depth(old), len(rel_parts))
        anchor_depth, anchor_rel_depth = self._anchor
        depth = anchor_rel_depth + self._pathname_depth(event.new) - anchor_depth
        state.rel_path = rel_path = '/'.join(['..'] * max(depth, 0))
        if 'static/extensions/panel/' in doc._template_variables.get('dist_url', ''):
            doc._template_variables['dist_url'] = f"{rel_path}/{LOCAL_DIST}" if rel_path else LOCAL_DIST
        state._stylesheets.pop(doc, None)

    def get_root(
        self, doc: Document | None = None, comm: Comm | None = None,
        preprocess: bool = True
    ) -> Model:
        doc = create_doc_if_none_exists(doc)
        root = self._get_model(doc, comm=comm)
        ref = root.ref['id']
        state._views[ref] = (self, root, doc, comm)
        self._documents[doc] = root
        return root

    def _server_destroy(self, session_context: BokehSessionContext) -> None:
        for p, ps, _, _ in self._synced:
            try:
                self.unsync(p, ps)
            except Exception:
                pass
        super()._server_destroy(session_context)

    def _cleanup(self, root: Model | None = None) -> None:
        if root:
            if root.document in self._documents:
                del self._documents[root.document]
            ref = root.ref['id']
        else:
            ref = None
        super()._cleanup(root)
        if ref in state._views:
            del state._views[ref]

    def _update_synced(self, event: param.parameterized.Event | None = None) -> None:
        if self._syncing:
            return
        query_params = self.query_params
        raw_params = dict(urlparse.parse_qsl(self.search[1:]))
        for p, parameters, _, on_error in self._synced:
            mapping = {v: k for k, v in parameters.items()}
            mapped = {}
            for k, v in query_params.items():
                if k not in mapping:
                    continue
                pname = mapping[k]
                if isinstance(p.param[pname], param.String):
                    # parse_query converts numeric, boolean and JSON-like
                    # strings, but a String parameter takes the raw value
                    v = raw_params[k]
                elif pname == 'value' and k in raw_params:
                    # Selectors hold their options as given, so an option
                    # such as '02' must not be coerced to the int 2
                    try:
                        if is_in(raw_params[k], list(p.values)):
                            v = raw_params[k]
                    except Exception:
                        pass
                try:
                    v = p.param[pname].deserialize(v)
                except Exception:
                    pass
                try:
                    equal = is_equal(v, getattr(p, pname))
                except Exception:
                    equal = False

                if not equal:
                    mapped[pname] = v
            try:
                p.param.update(**mapped)
            except Exception:
                if on_error:
                    on_error(mapped)

    def _update_query(
        self, *events: param.parameterized.Event, query: dict[str, t.Any] | None = None
    ) -> None:
        if self._syncing:
            return
        serialized = query or {}
        for e in events:
            matches = [
                ps for o, ps, _, _ in self._synced
                if o in (e.cls, e.obj) and e.name in ps
            ]
            if not matches:
                continue
            owner = e.cls if e.obj is None else e.obj
            try:
                val = owner.param[e.name].serialize(e.new)
            except Exception:
                val = e.new
            if not isinstance(val, str):
                val = json.dumps(val)
            serialized[matches[0][e.name]] = val
        self._syncing = True
        try:
            self.update_query(**{k: v for k, v in serialized.items() if v is not None})
        finally:
            self._syncing = False

    @property
    def query_params(self) -> dict[str, t.Any]:
        return parse_query(self.search)

    def update_query(self, **kwargs: Mapping[str, t.Any]) -> None:
        query = self.query_params
        query.update(kwargs)
        self.search = '?' + urlparse.urlencode(query)

    def sync(
        self, parameterized: param.Parameterized, parameters: list[str] | dict[str, str] | None = None,
        on_error: Callable[[dict[str, t.Any]], None] | None = None
    ) -> None:
        """
        Syncs the parameters of a Parameterized object with the query
        parameters in the URL. If no parameters are supplied all
        parameters except the name are synced.

        Parameters
        ----------
        parameterized (param.Parameterized):
          The Parameterized object to sync query parameters with
        parameters (list or dict):
          A list or dictionary specifying parameters to sync.
          If a dictionary is supplied it should define a mapping from
          the Parameterized's parameters to the names of the query
          parameters.
        on_error: (callable):
          Callback when syncing Parameterized with URL parameters
          fails. The callback is passed a dictionary of parameter
          values, which could not be applied.
        """
        explicit = bool(parameters)
        parameters = parameters or [p for p in parameterized.param if p != 'name']
        if not isinstance(parameters, dict):
            parameters = dict(zip(parameters, parameters))
        if explicit:
            constant = [
                p for p in parameters
                if p in parameterized.param and parameterized.param[p].constant
            ]
            if constant:
                raise ValueError(
                    f"Cannot sync constant parameter(s) {constant} of "
                    f"{type(parameterized).__name__} with the URL."
                )
        watcher = parameterized.param.watch(self._update_query, list(parameters))
        self._synced.append((parameterized, parameters, watcher, on_error))
        self._update_synced()
        query = {}
        for p, name in parameters.items():
            v = getattr(parameterized, p)
            if v is None:
                continue
            try:
                v = parameterized.param[p].serialize(v)
            except Exception:
                pass
            if not isinstance(v, str):
                v = json.dumps(v)
            query[name] = v
        self._update_query(query=query)

    def unsync(self, parameterized: param.Parameterized, parameters: list[str] | None = None) -> None:
        """
        Unsyncs the parameters of the Parameterized with the query
        params in the URL. If no parameters are supplied all
        parameters except the name are unsynced.

        Parameters
        ----------
        parameterized (param.Parameterized):
          The Parameterized object to unsync query parameters with
        parameters (list):
          A list of parameters to unsync.
        """
        matches = [s for s in self._synced if s[0] is parameterized]
        if not matches:
            ptype = type(parameterized)
            raise ValueError(f"Cannot unsync {ptype} object since it "
                             "was never synced in the first place.")
        synced, unsynced = [], []
        for p, params, watcher, on_error in self._synced:
            if parameterized is not p:
                synced.append((p, params, watcher, on_error))
                continue
            parameterized.param.unwatch(watcher)
            if parameters is None:
                unsynced.extend(list(params.values()))
            else:
                unsynced.extend([q for p, q in params.items() if p in parameters])
                new_params = {p: q for p, q in params.items()
                              if p not in parameters}
                new_watcher = parameterized.param.watch(watcher.fn, list(new_params))
                synced.append((p, new_params, new_watcher, on_error))
        self._synced = synced
        query = {k: v for k, v in self.query_params.items() if k not in unsynced}
        self.search = '?' + urlparse.urlencode(query) if query else ''
