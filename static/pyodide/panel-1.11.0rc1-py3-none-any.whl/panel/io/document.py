from __future__ import annotations

import asyncio
import contextvars
import dataclasses
import datetime as dt
import gc
import inspect
import json
import logging
import sys
import threading
import time
import typing as t
import weakref

from collections import deque
from contextlib import ExitStack, contextmanager, nullcontext
from functools import partial, wraps
from weakref import WeakKeyDictionary

from bokeh.application.application import SessionContext
from bokeh.document.document import Document
from bokeh.document.events import (
    ColumnDataChangedEvent, ColumnsPatchedEvent, ColumnsStreamedEvent,
    DocumentChangedEvent, DocumentPatchedEvent, MessageSentEvent,
    ModelChangedEvent, SessionCallbackAdded, SessionCallbackRemoved,
    TitleChangedEvent,
)
from bokeh.model import Model
from bokeh.model.util import (
    collect_models, visit_value_and_its_immediate_references,
)
from bokeh.models import CustomJS
from bokeh.server.session import _needs_document_lock_on_loop

from ..config import config
from .loading import _loading_css_classes
from .model import monkeypatch_events  # noqa: F401 API import
from .state import set_curdoc, state

if t.TYPE_CHECKING:
    from asyncio.futures import Future
    from collections.abc import (
        Callable, Iterable, Iterator, Sequence,
    )

    from bokeh.core.enums import HoldPolicyType
    from bokeh.core.has_props import HasProps
    from bokeh.core.types import ID
    from bokeh.protocol.message import Message
    from bokeh.server.connection import ServerConnection
    from bokeh.server.session import ServerSession
    from pyviz_comms import Comm

    EventBatch: t.TypeAlias = tuple[list[ServerConnection], list[DocumentPatchedEvent]]

logger = logging.getLogger(__name__)

#---------------------------------------------------------------------
# Private API
#---------------------------------------------------------------------

GC_DEBOUNCE = 5
_MODEL_CHANGE_EVENTS = (ModelChangedEvent, ColumnDataChangedEvent, ColumnsStreamedEvent, ColumnsPatchedEvent)
_HOLD_LOCK: WeakKeyDictionary[Document, threading.Lock] = WeakKeyDictionary()
# The policy requested for a hold Panel established; the Document itself
# always collects, see _hold_doc.
_HOLD_POLICY: WeakKeyDictionary[Document, HoldPolicyType] = WeakKeyDictionary()
# The thread that established the hold Panel put on a Document.
_HOLD_THREAD: WeakKeyDictionary[Document, int] = WeakKeyDictionary()
_WRITE_FUTURES: WeakKeyDictionary[Document, list[Future]] = WeakKeyDictionary()
_WRITE_EVENTS: WeakKeyDictionary[Document, deque[EventBatch]] = WeakKeyDictionary()
_WRITE_BLOCK: WeakKeyDictionary[Document, bool] = WeakKeyDictionary()
_WRITE_LOCK = threading.Lock()
_UNCONNECTED_EVENTS: WeakKeyDictionary[Document, list[DocumentChangedEvent]] = WeakKeyDictionary()
_SCHEDULED_UPDATES: WeakKeyDictionary[Document, deque[Callable[[], t.Any]]] = WeakKeyDictionary()
_SCHEDULED_UPDATES_LOCK = threading.Lock()
# Events held back until another context releases the document lock
_DEFERRED_EVENTS: WeakKeyDictionary[Document, list[DocumentChangedEvent]] = WeakKeyDictionary()
# The (model id, attribute) keys the deferred events change
_DEFERRED_KEYS: WeakKeyDictionary[Document, set[tuple[str, str]]] = WeakKeyDictionary()
# Messages serialized but not yet written to the client
_UNWRITTEN: WeakKeyDictionary[Document, list[_Unwritten]] = WeakKeyDictionary()
# The keys of a session's pending writes and how many of them were read,
# since Bokeh only appends to the list while a locked callback runs
_PENDING_KEYS: WeakKeyDictionary[ServerSession, tuple[list, int, set[tuple[str, str]]]] = WeakKeyDictionary()

_panel_last_cleanup = None
_write_tasks: WeakKeyDictionary[Document, list[asyncio.Task]] = WeakKeyDictionary()

extra_socket_handlers: dict[type, Callable[..., Sequence[Future]]] = {}

@dataclasses.dataclass(eq=False)
class _Unwritten:
    """
    The models a message serialized but not yet written defines (or may
    define) and the properties it changes.
    """

    models: set[ID]
    changes: set[tuple[str, str]]


@dataclasses.dataclass
class Request:
    headers : dict
    cookies : dict
    arguments : dict


class MockSessionContext(SessionContext):

    def __init__(self, document: Document):
        self._document = document
        super().__init__(server_context=None, session_id=None)  # type: ignore[arg-type]

    def with_locked_document(self, *args):
        return

    @property
    def session(self):
        return None

    @property
    def destroyed(self) -> bool:
        return False

    @property
    def document(self) -> Document:
        return self._document

    @property
    def request(self):
        return Request(headers={}, cookies={}, arguments={})

def _cleanup_task(doc: Document, task: asyncio.Task) -> None:
    tasks = _write_tasks.get(doc)
    if tasks and task in tasks:
        tasks.remove(task)

def _hold_doc(doc: Document, policy: HoldPolicyType = 'combine') -> None:
    """
    Puts the Document on hold. Bokeh's 'combine' policy scans all held
    events for every new one, which is quadratic in the number of
    distinct changes, so the Document always collects and the events are
    combined when they are released, see ``_combine_events``.
    """
    _HOLD_POLICY[doc] = policy
    _HOLD_THREAD[doc] = threading.get_ident()
    doc.hold('collect')

def _combine_events(events: Iterable[DocumentChangedEvent]) -> list[DocumentChangedEvent]:
    """
    Merges events that set the same model property, or the title, into
    the first such event, which ends up carrying the last value and
    callback invoker, exactly as bokeh's 'combine' hold policy does, but
    in linear time.
    """
    combined: list[DocumentChangedEvent] = []
    index: dict[tuple[t.Any, ...], int] = {}
    for event in events:
        if isinstance(event, ModelChangedEvent) and getattr(event, 'hint', None) is None:
            key: tuple[t.Any, ...] = (
                ModelChangedEvent, event.model.id, event.attr, id(event.setter), id(event.document)
            )
        elif isinstance(event, TitleChangedEvent):
            key = (TitleChangedEvent, id(event.setter), id(event.document))
        else:
            combined.append(event)
            continue
        position = index.get(key)
        if position is None:
            index[key] = len(combined)
            combined.append(event)
            continue
        first = combined[position]
        if isinstance(event, ModelChangedEvent):
            first.new = event.new  # type: ignore[attr-defined]
        else:
            first.title = event.title  # type: ignore[attr-defined]
        first.callback_invoker = event.callback_invoker
    return combined

def _drop_unsent_model_changes(
    doc: Document, events: list[DocumentChangedEvent]
) -> list[DocumentChangedEvent]:
    """
    Drops changes to models the client has not been sent yet, since the
    message that first defines a model serializes its current state.

    Combining merges a later change into the slot of an earlier one,
    which can discard the only definition of a model that a change
    between the two refers to, leaving the client unable to decode the
    patch. Skipped while no model counts as sent, e.g. for an embedder
    that never serialized the Document, whose bookkeeping is unreliable.
    """
    unsent = getattr(doc.models, '_new_models', None)
    if not unsent or len(unsent) >= len(doc.models):
        return events
    return [
        event for event in events
        if not (isinstance(event, _MODEL_CHANGE_EVENTS) and event.model in unsent)
    ]

def _take_held_events(doc: Document) -> list[DocumentChangedEvent]:
    """
    Removes the events held on the Document and returns them, combined
    unless the hold was requested with the 'collect' policy.
    """
    events = list(doc.callbacks._held_events or [])
    doc.callbacks._held_events = []
    if _HOLD_POLICY.pop(doc, 'combine') == 'combine':
        events = _combine_events(_drop_unsent_model_changes(doc, events))
    return events

def _client_has_document(doc: Document) -> bool:
    """
    Whether the client was sent the Document, after which held events
    must not be dropped. ``state._connected`` is only set once it is ready.
    """
    if state._connected.get(doc):
        return True
    if doc.session_context is None and not any(
        comm is not None and view_doc is doc
        for _, _, view_doc, comm in state._views.values()
    ):
        # Serializing the document, e.g. to save it, also marks models
        # sent, so only an embedder that subscribed to its changes to sync
        # them over its own transport counts as a client.
        return bool(doc.callbacks.change_callbacks())
    live = getattr(doc.models, '_models', None)
    unsent = getattr(doc.models, '_new_models', None)
    if not live or unsent is None:
        return False
    return any(model not in unsent for model in live.values())

def _dispatch_events(doc: Document, events: list[DocumentChangedEvent]) -> None:
    """
    Handles dispatch of events which could not be processed in
    unlocked decorator.
    """
    for event in events:
        doc.callbacks.trigger_on_change(event)

def _drain_unconnected_events(doc: Document, lock: threading.Lock) -> list[DocumentChangedEvent]:
    """
    Drains events collected by a hold that exited before the session
    connected, sorting them into three groups, and returns the events
    that have to be dispatched immediately.

    Session callback events must be dispatched, since they are how
    ``add_next_tick_callback`` and friends register the callback on the
    IOLoop. Dropping them means the callback never runs at all, which
    for a scheduled ``Reactive._update_model`` silently loses the update.

    Events that carry no model state cannot be dispatched yet, since
    there are no subscribed connections to write them to, so they are
    deferred until the session connects. This currently means
    MessageSentEvent, i.e. custom events sent via ``Reactive._send_event``
    and ipywidgets comm messages.

    Everything else is dropped, since the Document is serialized in full
    once the session connects. Model property changes, title changes,
    root additions/removals and ColumnDataSource stream/patch events are
    all applied to the model before the event is emitted, so the
    serialization reproduces them.

    The events are returned rather than dispatched here so the caller can
    dispatch them after releasing ``lock``, since a change callback may
    itself enter ``hold``.
    """
    with lock:
        events = list(doc.callbacks._held_events or [])
        doc.callbacks._held_events = []
        doc.callbacks._hold = None

        dispatch: list[DocumentChangedEvent] = []
        deferred: list[DocumentChangedEvent] = []
        for event in events:
            if isinstance(event, (SessionCallbackAdded, SessionCallbackRemoved)):
                dispatch.append(event)
            elif not isinstance(event, DocumentPatchedEvent) or isinstance(event, MessageSentEvent):
                deferred.append(event)
        if deferred:
            _UNCONNECTED_EVENTS.setdefault(doc, []).extend(deferred)
    return dispatch

def _dispatch_unconnected_events(doc: Document) -> None:
    """
    Dispatches events deferred by ``_drain_unconnected_events`` now
    that the session has connected. Scheduled on the Document to ensure
    the events are dispatched on the Document's thread while it holds
    its lock, since ``_on_load`` may run on the thread pool.
    """
    events = _UNCONNECTED_EVENTS.pop(doc, None)
    if not events:
        return
    if doc.session_context:
        doc.add_next_tick_callback(partial(retrigger_events, doc, events))
    else:
        retrigger_events(doc, events)

def _is_destroyed(doc: Document) -> bool:
    # bokeh has no destroyed flag, Document.destroy deletes the roots
    return not hasattr(doc, '_roots')

def _clear_document_state(doc: Document) -> None:
    """
    Drops the Document from the per-Document registries on ``state``.

    These are WeakKeyDictionaries, but a value that refers back to the
    Document (e.g. a Location whose model callbacks hold it, or a
    stylesheet model attached to it) keeps its own key alive, so the
    entries have to be removed explicitly.
    """
    for attr in dir(state):
        # _param_watchers is deprecated in Param 2.0 and will raise a warning
        if not attr.startswith('_') or attr == "_param_watchers":
            continue
        state_obj = getattr(state, attr)
        if isinstance(state_obj, weakref.WeakKeyDictionary) and doc in state_obj:
            del state_obj[doc]

def _cleanup_doc(doc, destroy=True):
    from ..viewable import Viewable
    views = [(ref, view) for ref, view in state._views.items() if view[2] is doc]

    # The callbacks look the Document up on the session context, so a
    # Document without a session (e.g. one created by the liveness
    # endpoint) is given a mock one, otherwise none of them run.
    if destroy:
        session_context = doc.session_context or MockSessionContext(doc)
    else:
        session_context = None
    for callback in list(doc.session_destroyed_callbacks):
        try:
            callback(session_context)
        except Exception:
            pass
    if not destroy:
        doc.callbacks._change_callbacks.clear()
    elif None not in doc.callbacks._change_callbacks:
        doc.callbacks._change_callbacks[None] = lambda e: e

    # Remove views
    for ref, (pane, root, _vdoc, _comm) in views:
        # A root's _server_destroy callback may have cleaned it up already
        if ref in state._views:
            pane._cleanup(root)
        if isinstance(pane, Viewable):
            pane._hooks = []
            for p in pane.select():
                p._hooks = []
                p.param.watchers = {}
                p._documents = {}
                p._internal_callbacks = {}
        pane.param.watchers = {}
        pane._documents = {}
        pane._internal_callbacks = {}
        state._views.pop(ref, None)

    # When reusing sessions we must clean up the Panel state but we
    # must **not** destroy the template or the document
    if not destroy:
        return

    # Clean up templates
    if doc in state._templates:
        tmpl = state._templates[doc]
        tmpl._documents = []
        del state._templates[doc]

    _clear_document_state(doc)

    # Destroy document
    doc.destroy(None)

async def _run_write_futures(doc):
    """
    Ensure that all write_message calls are awaited and handled.
    """
    await _await_writes(_WRITE_FUTURES.pop(doc, []))

async def _await_writes(futures: Iterable[Future]) -> None:
    from tornado.websocket import WebSocketClosedError
    for future in futures:
        try:
            await future
        except WebSocketClosedError:
            logger.warning("Failed sending message as connection was closed")
        except Exception as e:
            logger.warning(f"Failed sending message due to following error: {e}")

def _log_task_exception(task: asyncio.Task) -> None:
    if task.cancelled():
        return
    if (exception := task.exception()) is not None:
        logger.error("Error thrown from callback:", exc_info=exception)

def _track_task(doc: Document, task: asyncio.Task) -> None:
    _write_tasks.setdefault(doc, []).append(task)
    task.add_done_callback(partial(_cleanup_task, doc))

@contextmanager
def _owning_document_lock(session: ServerSession) -> Iterator[None]:
    """
    Marks the calling context as holding the session's document lock and
    first writes the events other contexts held back while it was taken
    by someone else, so they precede the changes made under this lock.
    """
    with state._own_document_lock(session):
        if session.document in _DEFERRED_EVENTS:
            try:
                _dispatch_deferred_events(session.document)
            except Exception:
                logger.exception('Failed to dispatch deferred events')
        yield

def _run_owning_document_lock(session: ServerSession, func: Callable[..., t.Any], *args, **kwargs) -> t.Any:
    with _owning_document_lock(session):
        result = func(*args, **kwargs)
    if inspect.isawaitable(result):
        awaiting = _await_owning_document_lock(session, result)
        if inspect.iscoroutine(result):
            # Bokeh closes the callback's coroutine if it is cancelled
            # before awaiting it, which only reaches ours.
            weakref.finalize(awaiting, result.close)
        return awaiting
    return result

async def _await_owning_document_lock(session: ServerSession, awaitable: t.Awaitable) -> t.Any:
    with state._own_document_lock(session):
        return await awaitable

@_needs_document_lock_on_loop
def _run_with_document_lock(session: ServerSession, func: Callable[..., t.Any], *args, **kwargs) -> t.Any:
    return _run_owning_document_lock(session, func, *args, **kwargs)


def _unsent_models(doc: Document) -> set[Model]:
    # Copied in one step, since the lock holder may add to it meanwhile
    return set(getattr(doc.models, '_new_models', ()))

def _event_target(event: DocumentChangedEvent) -> Model | None:
    model = getattr(event, 'model', None)
    if model is None and isinstance(event, MessageSentEvent):
        model = getattr(event.msg_data, 'model', None)
    return model if isinstance(model, Model) else None

def _change_key(event: DocumentChangedEvent) -> tuple[str, str] | None:
    model, attr = getattr(event, 'model', None), getattr(event, 'attr', None)
    if model is None or attr is None:
        return None
    return (model.id, attr)

def _track_unwritten(
    doc: Document, models: Iterable[ID], events: Iterable[DocumentChangedEvent]
) -> _Unwritten:
    changes = {key for event in events if (key := _change_key(event))}
    record = _Unwritten(set(models), changes)
    with _WRITE_LOCK:
        _UNWRITTEN.setdefault(doc, []).append(record)
    return record

def _untrack_unwritten(doc: Document, record: _Unwritten) -> None:
    with _WRITE_LOCK:
        records = _UNWRITTEN.get(doc, [])
        if record in records:
            records.remove(record)
        if not records:
            _UNWRITTEN.pop(doc, None)
        release = doc in _DEFERRED_EVENTS
    if release:
        _release_deferred_events(doc)

async def _send_pending_patches_tracked(send_pending_patches, session: ServerSession, pending) -> None:
    """
    Tracks the changes a lock holder writes once its callback returned.
    Bokeh serializes them in a worker thread, so any model not yet sent
    when it starts may be defined by them.
    """
    doc = session.document
    unsent = [model.id for model in _unsent_models(doc)]
    record = _track_unwritten(doc, unsent, (patch.event for patch in pending))
    try:
        await send_pending_patches(session, pending)
    finally:
        _untrack_unwritten(doc, record)

def _is_unwritten(model: Model, records: list[_Unwritten]) -> bool:
    return any(model.id in record.models for record in records)

def _refers_to(value: t.Any, records: list[_Unwritten], unsent: set[Model]) -> bool:
    """
    Whether serializing value refers to a model only an unwritten
    message defines. Models the client has not been sent are serialized
    in full, so their references are followed, while any other model is
    only referenced.
    """
    seen: set[ID] = set()
    stack = _immediate_references(value)
    while stack:
        model = stack.pop()
        if _is_unwritten(model, records):
            return True
        if model.id in seen or model not in unsent:
            continue
        seen.add(model.id)
        for attr in model.properties_with_refs():
            stack.extend(_immediate_references(getattr(model, attr, None)))
    return False

def _pending_keys(session: ServerSession) -> set[tuple[str, str]]:
    """
    The keys of the changes the lock holder's callback made so far.
    Must be called holding _WRITE_LOCK.
    """
    pending = session._pending_writes
    try:
        cached = _PENDING_KEYS.get(session) if pending else _PENDING_KEYS.pop(session, None)
    except TypeError:
        cached = None
    if not pending:
        return set()
    if cached is not None and cached[0] is pending:
        _, read, keys = cached
    else:
        read, keys = 0, set()
    size = len(pending)
    for patch in pending[read:size]:
        if key := _change_key(patch.event):
            keys.add(key)
    try:
        _PENDING_KEYS[session] = (pending, size, keys)
    except TypeError:
        pass
    return keys

def _split_unknown_to_client(
    doc: Document, session: ServerSession, events: list[DocumentChangedEvent]
) -> tuple[list[DocumentChangedEvent], list[DocumentChangedEvent]]:
    """
    Splits off the events that must wait for changes another context
    has not written yet: changes to a model the client does not have,
    changes whose value refers to a model only an unwritten message
    defines, and changes to a property the unwritten changes also set,
    whose older value would otherwise overwrite the newer one.
    """
    # Only membership is tested below, so the key sets the other contexts
    # add to are not copied, keeping each flush independent of how many
    # changes are already waiting.
    with _WRITE_LOCK:
        records = list(_UNWRITTEN.get(doc, []))
        deferred = _DEFERRED_KEYS.get(doc, set())
        pending = _pending_keys(session)
        waiting = doc in _DEFERRED_EVENTS
    if not (records or waiting or pending or _is_locked_elsewhere(session)):
        return events, []
    unsent = getattr(doc.models, '_new_models', None) or set()
    held_keys: set[tuple[str, str]] = set()
    immediate, held = [], []
    for event in events:
        model = _event_target(event)
        key = _change_key(event)
        if isinstance(event, ModelChangedEvent):
            value = event.new
        elif isinstance(event, MessageSentEvent):
            value = event.msg_data
        else:
            value = None
        if (
            (model is not None and (model in unsent or _is_unwritten(model, records))) or
            (key is not None and (
                key in held_keys or key in deferred or key in pending or
                any(key in record.changes for record in records)
            )) or
            (records and value is not None and _refers_to(value, records, unsent))
        ):
            held.append(event)
            if key is not None:
                held_keys.add(key)
        else:
            immediate.append(event)
    return immediate, held

def _is_locked_elsewhere(session: ServerSession) -> bool:
    """
    Whether a context other than the calling one holds the session's
    document lock.
    """
    lock = getattr(session, '_lock', None)
    return bool(lock is not None and lock.locked() and not state._document_lock_held)

def _defer_until_unlocked(doc: Document, events: list[DocumentChangedEvent]) -> None:
    """
    Holds back events until the unwritten messages they wait for have
    been written or, failing that, until the context holding the
    document lock has released it, and with it written everything it
    changed.
    """
    events = _suppress_property_callbacks(events)
    with _WRITE_LOCK:
        _DEFERRED_KEYS.setdefault(doc, set()).update(
            key for event in events if (key := _change_key(event))
        )
        deferred = _DEFERRED_EVENTS.get(doc)
        # Only the latest value of a property has to reach the client
        _DEFERRED_EVENTS[doc] = _combine_events((deferred or []) + events)
        if deferred is not None:
            return
        awaiting_write = doc in _UNWRITTEN
    # Writing the last unwritten message releases them, otherwise the
    # next context taking the lock writes them first and this callback
    # only does so if no other context is waiting for the lock.
    if not awaiting_write:
        _schedule_locked(doc, _dispatch_deferred_events, doc)

def _dispatch_deferred_events(doc: Document) -> None:
    with _WRITE_LOCK:
        events = _DEFERRED_EVENTS.pop(doc, [])
        _DEFERRED_KEYS.pop(doc, None)
    session = getattr(doc.session_context, 'session', None)
    if not events or _is_destroyed(doc) or session is None:
        return
    with set_curdoc(doc):
        if doc.callbacks.hold_value:
            doc.callbacks._held_events += events
            return
        _hold_doc(doc, 'collect')
        doc.callbacks._held_events += events
        _flush_events(doc, session)

def _release_deferred_events(doc: Document) -> None:
    """
    Dispatches the deferred events once a message they may wait for was
    written. They are dispatched outside the document lock, so the ones
    that still have to wait are deferred again rather than waiting for
    the lock, which a busy lock holder may hardly ever release.
    """
    loop = state._document_loop(doc)
    asyncio_loop = t.cast(
        'asyncio.AbstractEventLoop | None', getattr(loop, 'asyncio_loop', loop)
    )
    if asyncio_loop is None:
        _schedule_locked(doc, _dispatch_deferred_events, doc)
        return
    try:
        # A fresh context, since the writer may still own the lock
        asyncio_loop.call_soon_threadsafe(
            _dispatch_deferred_events, doc, context=contextvars.Context()
        )
    except RuntimeError:
        # The loop is closed, so is the session
        pass

def _schedule_locked(doc: Document, func: Callable[..., t.Any], *args, **kwargs) -> None:
    """
    Runs ``func`` on the server event loop while holding the Document
    lock, awaiting its result if it is a coroutine. Unlike a next tick
    callback the function is not offloaded to a worker thread first
    and scheduling it emits no session callback events.
    """
    session = getattr(doc.session_context, 'session', None)
    loop = state._document_loop(doc)
    asyncio_loop = t.cast(
        'asyncio.AbstractEventLoop | None', getattr(loop, 'asyncio_loop', loop)
    )
    if session is None or asyncio_loop is None:
        doc.add_next_tick_callback(partial(func, *args, **kwargs))
        return

    def start() -> None:
        task = asyncio.ensure_future(
            _run_with_document_lock(session, func, *args, **kwargs), loop=asyncio_loop
        )
        _track_task(doc, task)
        task.add_done_callback(_log_task_exception)

    asyncio_loop.call_soon_threadsafe(start)

def _dispatch_write_task(doc, func, *args, **kwargs):
    """
    Schedules tasks that write messages to the socket.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        # No running loop on this thread (e.g. a callback offloaded to a
        # worker thread by Bokeh); avoid creating the coroutine here
        # since there is nothing to await it, and reschedule instead.
        _schedule_locked(doc, func, *args, **kwargs)
        return
    _track_task(doc, loop.create_task(func(*args, **kwargs)))

def _is_write_locked(conn: ServerConnection) -> bool:
    return _is_write_blocked(conn._socket)

def _socket_dispatcher(socket: t.Any) -> Callable[..., Sequence[Future]]:
    """
    Resolve the write dispatcher for a socket, matching the exact type
    first and then walking the MRO so that subclasses of a registered
    transport are also covered.
    """
    from tornado.websocket import WebSocketHandler
    if isinstance(socket, WebSocketHandler):
        return dispatch_tornado
    for cls in type(socket).__mro__:
        if cls in extra_socket_handlers:
            return extra_socket_handlers[cls]
    return dispatch_django


def _is_write_blocked(socket: t.Any) -> bool:
    """
    Whether a socket currently holds its write lock.

    Tornado's ``locks.Lock`` exposes the lock state as the value of an
    internal semaphore while Bokeh's ASGI ``_WriteLock`` wraps an
    ``asyncio.Lock``, so both have to be probed.
    """
    lock = getattr(socket, 'write_lock', None)
    if lock is None:
        return False
    if (block := getattr(lock, '_block', None)) is not None:
        return block._value == 0
    if (inner := getattr(lock, '_lock', None)) is not None:
        return inner.locked()
    return False


def _keep_unsent_models_new(doc: Document) -> None:
    """
    Keeps models Panel has not written yet unsent when a client patch is
    applied, since bokeh then declares all models synced.
    """
    if getattr(doc.apply_json_patch, '_panel_keeps_unsent', False):
        return
    if not hasattr(doc.models, '_new_models'):
        # A bokeh that tracks unsent models differently needs no patching
        logger.debug('Could not keep unsent models unsent, bokeh changed')
        return
    # A bound method would keep the Document alive in a cycle.
    apply_json_patch = type(doc).apply_json_patch
    ref = weakref.ref(doc)

    @wraps(apply_json_patch)
    def _apply_json_patch(*args, **kwargs):
        doc = ref()
        if doc is None:
            return None
        unsent = set(doc.models._new_models)
        try:
            return apply_json_patch(doc, *args, **kwargs)
        finally:
            live = getattr(doc.models, '_models', None)
            if unsent and live is not None:
                doc.models._new_models |= {
                    model for model in unsent if live.get(model.id) is model
                }

    _apply_json_patch._panel_keeps_unsent = True  # type: ignore[attr-defined]
    doc.apply_json_patch = _apply_json_patch  # type: ignore[method-assign]

async def _dispatch_msgs(doc):
    """
    Serializes and writes the queued batches of events to the sockets
    in order, waiting for each socket's write lock rather than writing
    while something else is writing to it. Only one dispatcher runs per
    Document, draining batches queued while it was writing, so the
    order the batches were scheduled in is preserved.

    The events are serialized here, i.e. at write time while holding
    the write lock, and not when they were scheduled. Bokeh tracks which
    models a client has already been sent as part of the Document, so
    serializing a patch declares the models it defines as synced.
    Serializing eagerly and writing later would therefore allow a
    message that was serialized after ours (e.g. one Bokeh itself
    dispatches at the end of a locked callback) to be written first,
    referencing models the client has not been sent yet.
    """
    while True:
        with _WRITE_LOCK:
            batches = _WRITE_EVENTS.get(doc)
            if not batches or doc not in _WRITE_BLOCK:
                if not batches:
                    _WRITE_EVENTS.pop(doc, None)
                _WRITE_BLOCK.pop(doc, None)
                return
            connections, events = batches[0]
            # Consecutive batches for the same connections share a message
            merged = 1
            while merged < len(batches) and batches[merged][0] == connections:
                events = events + batches[merged][1]
                merged += 1
        try:
            message = None
            for conn in connections:
                lock = getattr(conn._socket, 'write_lock', None)
                with (await lock.acquire()) if lock is not None else nullcontext():
                    if message is None:
                        message = conn.protocol.create('PATCH-DOC', events)
                    await _await_writes(_socket_dispatcher(conn._socket)(conn, msg=message))
        except Exception as e:
            logger.warning(f"Failed sending message due to following error: {e}")
        finally:
            with _WRITE_LOCK:
                # The destroyed document already dropped its queue
                if _WRITE_EVENTS.get(doc) is batches:
                    for _ in range(merged):
                        batches.popleft()

def _garbage_collect():
    if (new_time:= time.monotonic()-_panel_last_cleanup) < GC_DEBOUNCE:
        at = dt.datetime.now() + dt.timedelta(seconds=new_time)
        state.schedule_task('gc.collect', _garbage_collect, at=at)
        return
    gc.collect()

def _destroy_document(self, session):
    """
    Override for Document.destroy() without calling gc.collect directly.
    The gc.collect() call is scheduled as a task, ensuring that when
    multiple documents are destroyed in quick succession we do not
    schedule excessive garbage collection.
    """
    if session is not None:
        self.remove_on_change(session)

    del self._roots
    del self._theme
    del self._template
    self._session_context = None

    # Stopping a callback fires watchers on its parameters, which must run
    # before the callbacks and models below are torn down.
    for cb in state._periodic.get(self, []):
        cb.stop()

    self.callbacks.destroy()
    # The on_change callbacks Panel registers on the models are partials
    # holding the Document, so a model that outlives the session (e.g.
    # one a user kept a reference to) would otherwise keep all of it alive.
    for model in list(getattr(self.models, '_models', {}).values()):
        model._callbacks.clear()
        model._event_callbacks.clear()
    self.models.destroy()

    # Module cleanup without trawling through referrers (as self.modules.destroy() does)
    for module in self.modules._modules:
        # remove the reference from sys.modules
        if module.__name__ in sys.modules:
            del sys.modules[module.__name__]

        # explicitly clear the module contents and the module here itself
        module.__dict__.clear()
        del module
    self.modules._modules = []

    # Cancel any pending write tasks for this document
    with _WRITE_LOCK:
        _WRITE_EVENTS.pop(self, None)
        _WRITE_BLOCK.pop(self, None)
        _DEFERRED_EVENTS.pop(self, None)
        _DEFERRED_KEYS.pop(self, None)
        _UNWRITTEN.pop(self, None)
    _UNCONNECTED_EVENTS.pop(self, None)
    _HOLD_POLICY.pop(self, None)
    _HOLD_THREAD.pop(self, None)
    with _SCHEDULED_UPDATES_LOCK:
        _SCHEDULED_UPDATES.pop(self, None)
    for future in _WRITE_FUTURES.pop(self, []):
        future.cancel()
    for task in _write_tasks.pop(self, []):
        task.cancel()

    # Clean up pn.state to avoid tasks getting executed on dead session
    _clear_document_state(self)

    # Schedule GC
    global _panel_last_cleanup
    _panel_last_cleanup = time.monotonic()
    at = dt.datetime.now() + dt.timedelta(seconds=GC_DEBOUNCE)
    state.schedule_task('gc.collect', _garbage_collect, at=at)

    if 'destroy' in self.__dict__:
        del self.destroy

#---------------------------------------------------------------------
# Public API
#---------------------------------------------------------------------

def retrigger_events(doc: Document, events: list[DocumentChangedEvent]):
    """
    Applies events that could not be processed previously.
    """
    if doc.callbacks.hold_value:
        doc.callbacks._held_events = events + list(doc.callbacks._held_events)
    else:
        _dispatch_events(doc, events)

def write_events(
    doc: Document,
    connections: Iterable[ServerConnection],
    events: list[DocumentPatchedEvent],
    run: bool = True
) -> list[Future]:
    """
    Serializes the events into a single protocol message and writes it
    to all the supplied connections.

    A single message is shared between the connections since serializing
    a patch marks the models it defines as synced on the Document, so
    serializing per connection would make all but the first message
    reference models the client was never sent.
    """
    connections = list(connections)
    if not connections or not events:
        return []

    msg = connections[0].protocol.create('PATCH-DOC', events)

    futures: list[Future] = []
    for conn in connections:
        futures += _socket_dispatcher(conn._socket)(conn, msg=msg)

    if not run:
        return futures

    if doc in _WRITE_FUTURES:
        _WRITE_FUTURES[doc] += futures
    else:
        _WRITE_FUTURES[doc] = futures

    if state._unblocked(doc):
        _dispatch_write_task(doc, _run_write_futures, doc)
    else:
        doc.add_next_tick_callback(partial(_run_write_futures, doc))  # type: ignore[arg-type]
    return futures

def schedule_model_update(doc: Document, callback: Callable[[], t.Any]) -> None:
    """
    Queues a model update that may only be applied while the Document
    lock is held, e.g. one made from a thread that does not own it, and
    schedules one locked callback per Document that applies all queued
    updates and writes them in a single message.
    """
    with _SCHEDULED_UPDATES_LOCK:
        pending = _SCHEDULED_UPDATES.get(doc)
        if pending is None:
            _SCHEDULED_UPDATES[doc] = pending = deque()
        pending.append(callback)
        schedule = len(pending) == 1
    if not schedule:
        return
    try:
        _schedule_locked(doc, _apply_scheduled_updates, doc)
    except Exception:
        with _SCHEDULED_UPDATES_LOCK:
            _SCHEDULED_UPDATES.pop(doc, None)
        raise

def _apply_scheduled_updates(doc: Document) -> None:
    with _SCHEDULED_UPDATES_LOCK:
        pending = _SCHEDULED_UPDATES.pop(doc, None)
    if not pending:
        return
    errors: list[Exception] = []
    with set_curdoc(doc):
        # Every queued update is written, so updates to the same property
        # must not be combined into the last one.
        with unlocked(policy='collect'):
            for callback in pending:
                try:
                    callback()
                except Exception as e:
                    errors.append(e)
        for error in errors:
            state._handle_exception(error)

def schedule_write_events(
    doc: Document,
    connections: Iterable[ServerConnection],
    events: list[DocumentPatchedEvent]
):
    """
    Queues events that cannot be written immediately, e.g. because the
    socket is being written to or because we are not on the event loop
    thread. The events are serialized by ``_dispatch_msgs`` when they
    are actually written.
    """
    with _WRITE_LOCK:
        batches = _WRITE_EVENTS.get(doc)
        if batches is None:
            _WRITE_EVENTS[doc] = batches = deque()
        batches.append((list(connections), events))
        if doc in _WRITE_BLOCK:
            # The running dispatcher drains the queue
            return
        _WRITE_BLOCK[doc] = True
    _dispatch_write_task(doc, _dispatch_msgs, doc)

def create_doc_if_none_exists(doc: Document | None) -> Document:
    curdoc = doc or state.curdoc
    if curdoc is None:
        curdoc = Document()
    elif not isinstance(curdoc, Document):
        curdoc = curdoc._doc
    return curdoc

def init_doc(doc: Document | None) -> Document:
    curdoc = create_doc_if_none_exists(doc)
    if not curdoc.session_context:
        return curdoc

    thread_id = threading.get_ident()
    if thread_id:
        state._thread_id_[curdoc] = thread_id

    _keep_unsent_models_new(curdoc)

    if config.global_loading_spinner:
        curdoc.js_on_event(
            'document_ready', CustomJS(code=f"""
            const body = document.getElementsByTagName('body')[0]
            body.classList.remove(...{json.dumps(_loading_css_classes())})
            """)
        )

    session_id = curdoc.session_context.id
    sessions = state.session_info['sessions']
    if session_id not in sessions:
        return curdoc

    sessions[session_id].update({
        'started': dt.datetime.now().timestamp()
    })
    curdoc.on_event('document_ready', state._init_session)
    return curdoc

def with_lock(func: Callable) -> Callable:
    """
    Wrap a callback function to execute with a lock allowing the
    function to modify bokeh models directly.

    Parameters
    ----------
    func: callable
      The callable to wrap

    Returns
    -------
    wrapper: callable
      Function wrapped to execute without a Document lock.
    """
    if inspect.iscoroutinefunction(func):
        @wraps(func)
        async def wrapper(*args, **kw):
            return await func(*args, **kw)
    else:
        @wraps(func)
        def wrapper(*args, **kw):
            return func(*args, **kw)
    wrapper.lock = True # type: ignore
    return wrapper

def dispatch_tornado(
    conn: ServerConnection,
    events: list[DocumentPatchedEvent] | None = None,
    msg: Message | None = None
) -> Sequence[Future]:
    from tornado.websocket import WebSocketClosedError, WebSocketHandler
    socket = conn._socket
    # _socket_dispatcher only resolves to dispatch_tornado for a socket
    # that is a WebSocketHandler.
    assert isinstance(socket, WebSocketHandler)
    ws_conn = getattr(socket, 'ws_connection', False)
    if not ws_conn or ws_conn.is_closing(): # type: ignore
        return []
    elif msg is None:
        if events:
            msg = conn.protocol.create('PATCH-DOC', events)
        else:
            return []
    frames: list[tuple[str | bytes, bool]] = [
        (msg.header_json, False), (msg.metadata_json, False), (msg.content_json, False)
    ]
    for buffer in msg._buffers:
        frames.extend([(json.dumps(buffer.ref), False), (buffer.to_bytes(), True)])
    futures: list[Future] = []
    for frame, binary in frames:
        try:
            futures.append(WebSocketHandler.write_message(socket, frame, binary=binary))
        except WebSocketClosedError:
            # A frame write failing aborts the connection, so the later
            # frames raise. The futures of the earlier frames are still
            # returned so the caller retrieves their errors.
            break
    return futures

def dispatch_django(
    conn: ServerConnection,
    events: list[DocumentPatchedEvent] | None = None,
    msg: Message | None = None
) -> Sequence[Future]:
    socket = conn._socket
    if msg is None:
        if not events:
            return []
        msg = conn.protocol.create('PATCH-DOC', events)
    futures = [
        socket.send(text_data=msg.header_json),
        socket.send(text_data=msg.metadata_json),
        socket.send(text_data=msg.content_json)
    ]
    for buffer in msg._buffers:
        header = json.dumps(buffer.ref)
        payload = buffer.to_bytes()
        futures.extend([
            socket.send(text_data=header),
            socket.send(binary_data=payload)
        ])
    return futures

def _release_held_events(doc: Document) -> None:
    """
    Releases a hold established by ``hold`` on a worker thread, letting
    bokeh dispatch the (combined) events it collected.
    """
    doc.callbacks._held_events = _suppress_property_callbacks(_take_held_events(doc))
    doc.unhold()

def _suppress_property_callbacks(
    events: list[DocumentChangedEvent]
) -> list[DocumentChangedEvent]:
    """
    Clears the ``callback_invoker`` on Python-side patch events so that
    handing them to bokeh only serializes and writes them.

    A held ModelChangedEvent carries the invoker that runs the
    property-level ``on_change`` callbacks, which bokeh defers until the
    event is dispatched. Since the change originated on the Python side
    inside a hold, ``Syncable._changing`` has already been torn down by
    the time the dispatch happens, so letting the invoker run makes
    ``Syncable._server_change`` treat the Python update as a frontend
    change and boomerang it back into the parameter.

    Frontend patches applied while the Document is held carry the session
    as their ``setter`` and keep their invoker, otherwise the change would
    never reach Python.
    """
    for event in events:
        if isinstance(event, DocumentPatchedEvent) and event.setter is None:
            event.callback_invoker = None
    return events

async def _write_message(
    doc: Document, connections: list[ServerConnection], message: Message,
    record: _Unwritten | None = None
) -> None:
    try:
        for conn in connections:
            lock = getattr(conn._socket, 'write_lock', None)
            with (await lock.acquire()) if lock is not None else nullcontext():
                await _await_writes(_socket_dispatcher(conn._socket)(conn, msg=message))
    except Exception as e:
        # Nothing awaits this task, so the error has to be handled here
        logger.warning(f"Failed sending message due to following error: {e}")
    finally:
        if record is not None:
            _untrack_unwritten(doc, record)

def _write_from_worker_thread(
    doc: Document,
    connections: Iterable[ServerConnection],
    events: list[DocumentChangedEvent]
) -> bool:
    """
    Writes events generated by a locked callback that bokeh runs on a
    worker thread right away, rather than leaving them to bokeh, which
    only writes them once the callback returns, so that a long running
    callback can still report progress.

    Only safe while bokeh has no pending writes of its own and the
    calling context owns the Document lock: the message is serialized
    here, while the callback holds the Document lock, and
    the write is scheduled on the event loop ahead of bokeh's, so the
    client always receives models before they are referenced.
    """
    patches = [e for e in events if isinstance(e, DocumentPatchedEvent)]
    if (
        state._on_loop_thread or not state._document_lock_held or
        not patches or len(patches) != len(events)
    ):
        return False
    loop = state._document_loop(doc)
    asyncio_loop = t.cast(
        'asyncio.AbstractEventLoop | None', getattr(loop, 'asyncio_loop', loop)
    )
    connections = list(connections)
    if asyncio_loop is None or asyncio_loop.is_closed() or not connections:
        return False
    unsent = _unsent_models(doc)
    # Tracked before serializing, which marks the models it defines as sent
    record = _track_unwritten(doc, (model.id for model in unsent), patches)
    message = connections[0].protocol.create('PATCH-DOC', patches)
    defined = {model.id for model in unsent - _unsent_models(doc)}
    with _WRITE_LOCK:
        record.models = defined
    try:
        asyncio_loop.call_soon_threadsafe(
            _dispatch_write_task, doc, _write_message, doc, connections, message, record
        )
    except RuntimeError:
        _untrack_unwritten(doc, record)
        raise
    return True

def _flush_events(curdoc: Document, session: ServerSession) -> None:
    """
    Dispatches the events held on a Document, either by writing them to
    the subscribed sockets directly, by queueing them to be serialized
    and written on a later iteration of the event loop, by letting bokeh
    dispatch them or by re-applying them at a later point in time.
    """
    connections = session._subscribed_connections

    # Events may only be written to the sockets from the server event
    # loop thread and only while nothing else is writing to them.
    # Bokeh dispatches locked session callbacks on a worker
    # thread, so this is frequently not the case.
    queued = curdoc in _WRITE_EVENTS or curdoc in _WRITE_BLOCK
    locked = queued or not state._on_loop_thread
    for conn in connections:
        if _is_write_locked(conn):
            locked = True
            break

    events = _take_held_events(curdoc)
    monkeypatch_events(events)

    # A context that does not hold the document lock, e.g. an unlocked
    # async callback on the event loop, writes right away, except for
    # changes that would reach the client ahead of unwritten changes of
    # the lock holder they depend on. Those join the holder's pending
    # writes while its callback runs, or are held back until it has
    # written them, so they follow the holder's changes in order.
    if not state._document_lock_held:
        events, held = _split_unknown_to_client(curdoc, session, events)
        if held:
            if session._pending_writes is not None:
                curdoc.callbacks._held_events += _suppress_property_callbacks(held)
                try:
                    curdoc.unhold()
                except RuntimeError:
                    # The holder finished writing in the meantime
                    curdoc.callbacks._hold = None
                    _defer_until_unlocked(curdoc, held)
                if events:
                    _hold_doc(curdoc, 'collect')
            else:
                _defer_until_unlocked(curdoc, held)
        if not events:
            curdoc.unhold()
            return

    if (
        not queued and session._pending_writes == [] and
        _write_from_worker_thread(curdoc, connections, events)
    ):
        curdoc.unhold()
        return

    # If we cannot write the events ourselves we let bokeh dispatch them,
    # as long as it is inside a locked callback and will therefore write
    # them before the callback returns. Deferring the write ourselves
    # would allow events bokeh dispatches later in the same callback to
    # be written first and since an event always refers to the model it
    # applies to by reference, reordering leaves the client
    # dereferencing models it has not been sent yet.
    # Only the lock holder's own changes join its pending writes. An
    # unlocked context on the loop queues them instead, since joining
    # would make its later changes to the same properties wait for the
    # lock holder to finish too.
    if (
        locked and not queued and session._pending_writes is not None and
        (state._document_lock_held or not state._on_loop_thread)
    ):
        curdoc.callbacks._held_events += _suppress_property_callbacks(events)
        try:
            curdoc.unhold()
        except RuntimeError:
            curdoc.add_next_tick_callback(partial(retrigger_events, curdoc, events))
        return

    remaining_events, writeable_events = [], []
    for event in events:
        if isinstance(event, DocumentPatchedEvent) and not locked:
            writeable_events.append(event)
        else:
            remaining_events.append(event)

    try:
        if writeable_events:
            write_events(curdoc, connections, writeable_events)
    except Exception:
        remaining_events = events
    finally:
        # If for whatever reasons there are still events that couldn't
        # be dispatched we queue them up and schedule a task to
        # serialize and write them on the next iteration of the event
        # loop. The events must not be serialized here, since that
        # would declare the models they define as synced on the
        # Document while the message is still unwritten, leaving any
        # message serialized in the meantime referencing models the
        # client has not been sent.
        serializable_events = [e for e in remaining_events if isinstance(e, DocumentPatchedEvent)]
        held_events = [e for e in remaining_events if not isinstance(e, DocumentPatchedEvent)]
        if serializable_events:
            try:
                schedule_write_events(curdoc, connections, serializable_events)
            except Exception:
                # If the scheduling fails we let bokeh handle them
                held_events = remaining_events
        curdoc.callbacks._held_events += held_events

        # Last we attempt to let bokeh handle these remaining events
        # if this also fails we reapply the event at a later point in
        # time. This should not happen but since network writes
        # are fickle we handle this case anyway.
        try:
            retriggered_events = list(curdoc.callbacks._held_events)
            curdoc.unhold()
        except RuntimeError:
            curdoc.add_next_tick_callback(partial(retrigger_events, curdoc, retriggered_events))

@contextmanager
def unlocked(policy: HoldPolicyType = 'combine') -> Iterator:
    """
    Context manager which unlocks a Document and dispatches
    ModelChangedEvents triggered in the context body to all sockets
    on current sessions.

    Parameters
    ----------
    policy: Literal['combine' | 'collect']
        One of 'combine' or 'collect' determining whether events
        setting the same property are combined or accumulated to be
        dispatched when the context manager exits.
    """
    curdoc = state.curdoc
    session_context = getattr(curdoc, 'session_context', None)
    session = getattr(session_context, 'session', None)
    if (curdoc is None or session is None or not state.loaded or
          state._jupyter_kernel_context):
        yield
        return
    elif curdoc.callbacks.hold_value:
        yield
        monkeypatch_events(curdoc.callbacks._held_events)
        return

    _hold_doc(curdoc, policy)
    try:
        yield
    finally:
        # Whether or not there was an error in the body of context manager
        # we may have captured some events. We will dispatch these
        # either by running the write futures, by scheduling them to be
        # serialized and written on the next iteration of the event loop,
        # by having bokeh dispatch them on calling unhold or by
        # scheduling them to be triggered later.
        _flush_events(curdoc, session)

def dispatch_events(events, doc: Document | None = None):
    doc = doc or state.curdoc
    if doc is None:
        return
    with immediate_dispatch(doc):
        doc.callbacks._held_events = events

@contextmanager
def hold(
    doc: Document | None = None,
    policy: HoldPolicyType = 'combine',
    comm: Comm | None = None,
    freeze: bool = False,
):
    """
    Context manager that holds events on a particular Document
    allowing them all to be collected and dispatched when the context
    manager exits. This allows multiple events on the same object to
    be combined if the policy is set to 'combine'.

    Parameters
    ----------
    doc: Document
        The Bokeh Document to hold events on.
    policy: HoldPolicyType
        One of 'combine', 'collect' or None determining whether events
        setting the same property are combined or accumulated to be
        dispatched when the context manager exits.
    comm: Comm
        The Comm to dispatch events on when the context manager exits.
    freeze: bool
        **Experimental.** Whether to freeze the Document model
        references for the duration of the hold. When True, defers
        expensive model graph recomputation
        (``doc.models.recompute()``) until the hold exits, which can
        significantly speed up batch updates that modify many models.
        Safe to nest with the per-model ``freeze_doc`` calls used
        internally, since Bokeh's freeze mechanism is
        reference-counted.
    """
    doc = doc or state.curdoc
    if doc is None:
        yield
        return
    if doc not in _HOLD_LOCK:
        _HOLD_LOCK[doc] = threading.Lock()
    hold_lock = _HOLD_LOCK[doc]
    with ExitStack() as stack:
        if freeze and hasattr(doc, 'models'):
            stack.enter_context(doc.models.freeze())
        threaded = not state._on_loop_thread
        held = doc.callbacks.hold_value
        holder = _HOLD_THREAD.get(doc) if held else None
        we_held = False
        try:
            if policy is None:
                doc.unhold()
                yield
            elif threaded:
                with hold_lock:
                    held = doc.callbacks.hold_value
                    if not held:
                        _hold_doc(doc, policy)
                        we_held = True
                yield
            else:
                with unlocked(policy=policy):
                    if not doc.callbacks.hold_value:
                        _hold_doc(doc, policy)
                    yield
        finally:
            if policy is None:
                pass
            elif threaded:
                if not held or we_held:
                    if not _client_has_document(doc):
                        _dispatch_events(doc, _drain_unconnected_events(doc, hold_lock))
                    elif doc.session_context is None:
                        # Without a server loop a next tick callback never
                        # runs, so the hold has to be released right away.
                        with hold_lock:
                            _release_held_events(doc)
                    else:
                        def _unhold(lock=hold_lock, doc=doc):
                            with lock:
                                _release_held_events(doc)
                        _schedule_locked(doc, _unhold)
            elif held:
                # Another thread may have released its hold meanwhile;
                # restoring it would collect events nothing releases.
                if doc.callbacks.hold_value or holder == threading.get_ident():
                    doc.callbacks._hold = held
            elif comm is not None:
                from .notebook import push

                # Release the hold so events bokeh is still dispatching are not collected
                doc.callbacks._hold = None
                doc.callbacks._held_events = _take_held_events(doc)
                push(doc, comm)
            elif not _client_has_document(doc):
                _dispatch_events(doc, _drain_unconnected_events(doc, hold_lock))
            else:
                doc.callbacks._held_events = _take_held_events(doc)
                doc.unhold()

@contextmanager
def immediate_dispatch(doc: Document | None = None):
    """
    Context manager to trigger immediate dispatch of events triggered
    inside the execution context even when Document events are
    currently on hold.

    Parameters
    ----------
    doc: Document
        The document to dispatch events on (if `None` then `state.curdoc` is used).
    """
    doc = doc or state.curdoc

    # Skip if not in a server context
    if not doc or not doc._session_context or not state._unblocked(doc):
        yield
        return

    old_events = doc.callbacks._held_events
    held = doc.callbacks._hold
    policy = _HOLD_POLICY.pop(doc, None)
    doc.callbacks._held_events = []
    doc.callbacks.unhold()
    with unlocked():
        yield
    doc.callbacks._hold = held
    doc.callbacks._held_events = old_events
    if policy is not None:
        _HOLD_POLICY[doc] = policy

def _immediate_references(value: t.Any) -> list[Model]:
    # Layout children are flat lists of models, which bokeh's generic
    # visitor walks slowly enough to matter for thousands of children.
    if isinstance(value, list) and all(isinstance(v, Model) for v in value):
        return list(value)
    refs: list[Model] = []
    visit_value_and_its_immediate_references(value, refs.append)
    return refs


def _attach_models(doc: Document, models: Iterable[Model]) -> None:
    """
    Attaches the models reachable from the supplied models to the
    Document, mirroring what bokeh's recompute does for new models
    without visiting every model already in the Document.
    """
    manager = doc.models
    for model in collect_models(*models):
        if model.id in manager._models:
            continue
        manager._models[model.id] = model
        if model.name is not None:
            manager._models_by_name.add_value(model.name, model)
        model._attach_document(doc)
        manager._new_models.add(model)


@contextmanager
def freeze_doc(doc: Document, model: HasProps, properties: dict[str, t.Any], force: bool = False):
    """
    Freezes the document model references while the properties are
    applied to the model if any of them reference models, so bokeh
    recomputes the model graph once rather than per property.

    Recomputing visits every model in the Document, which makes
    updating a large layout expensive, so when the properties only
    add references (e.g. appending to a layout) and nothing else
    changed the model graph while frozen the added models are
    attached directly instead.
    """
    if _is_destroyed(doc):
        yield
        return

    changed_refs = 0
    added: list[Model] = []
    removed = False
    for key, value in properties.items():
        old = getattr(model, key, None)
        old_refs = _immediate_references(old)
        new_refs = _immediate_references(value)
        if not (old_refs or new_refs):
            continue
        # bokeh only invalidates the graph for a property it actually changed
        descriptor = model.lookup(key, raises=False)
        if descriptor is not None and not descriptor.property.matches(value, old):
            changed_refs += 1
        old_ids = {id(ref) for ref in old_refs}
        new_ids = {id(ref) for ref in new_refs}
        removed |= any(id(ref) not in new_ids for ref in old_refs)
        added.extend(ref for ref in new_refs if id(ref) not in old_ids)

    if not (force or changed_refs or added or removed):
        yield
        return

    manager = doc.models
    invalidations = 0
    # Shadow invalidate on the instance while frozen so we learn whether
    # anything but the properties above changed the graph. Nested
    # freezes forward their count since their changes are not ours.
    outer = manager.__dict__.get('invalidate')
    def invalidate() -> None:
        nonlocal invalidations
        invalidations += 1
        if outer is not None:
            outer()
    manager._push_freeze()
    manager.invalidate = invalidate  # type: ignore[method-assign]
    try:
        yield
    finally:
        if outer is None:
            del manager.invalidate
        else:
            manager.invalidate = outer  # type: ignore[method-assign]
        if (manager._freeze_count == 1 and not removed and
            invalidations == changed_refs and getattr(model, 'document', None) is doc):
            manager._freeze_count = 0
            if added:
                _attach_models(doc, added)
        else:
            manager._pop_freeze()
