"""
Utilities for building custom models included in panel.
"""
import fnmatch
import glob
import inspect
import io
import json
import os
import pathlib
import re
import shutil
import tarfile
import zipfile

from concurrent.futures import ThreadPoolExecutor
from functools import cache, partial
from urllib.parse import urljoin

import requests

from bokeh.model import Model

from .config import config, panel_extension
from .io.resources import CDN_DIST, RESOURCE_URLS
from .models.tabulator import TABULATOR_VERSION
from .reactive import ReactiveHTML
from .template.base import BasicTemplate
from .theme import Design
from .util import _descendents

BASE_DIR = pathlib.Path(__file__).parent
BUNDLE_DIR = pathlib.Path(__file__).parent / 'dist' / 'bundled'
LICENSE_DIR = BUNDLE_DIR / 'licenses'

# npm mandates no filename for license text, so each conventional spelling is
# tried in turn.
LICENSE_NAMES = (
    'LICENSE', 'LICENSE.txt', 'LICENSE.md', 'LICENCE', 'LICENCE.txt',
    'LICENSE-MIT', 'COPYING',
)

# The libraries Panel takes from a CDN that is not npm shaped, mapped to the
# npm release the bundled build corresponds to. Pinned rather than derived from
# the url so that bumping a version without updating this table fails the build
# instead of quietly shipping the terms of a different release.
LICENSE_PACKAGES = {
    'https://api.mapbox.com/mapbox-gl-js/v3.0.1/': 'mapbox-gl@3.0.1',
    'https://cdn.plot.ly/plotly-3.1.0.min.js': 'plotly.js-dist-min@3.1.0',
    'https://use.fontawesome.com/releases/v5.15.4/': '@fortawesome/fontawesome-free@5.15.4',
}

# npm specifier -> urls bundled from it, populated as the resources are collected
_LICENSE_SOURCES: dict[str, set[str]] = {}


@cache
def _session():
    try:
        import platformdirs

        from cachecontrol import CacheControl
        from cachecontrol.caches import SeparateBodyFileCache
        cache_dir = platformdirs.user_cache_path() / 'holoviz' / 'panel.compiler'

        return CacheControl(requests.Session(), cache=SeparateBodyFileCache(cache_dir))
    except ImportError:
        return requests.Session()


def _download(url):
    try:
        response, error = _session().get(url, timeout=10), None
    except Exception:
        try:
            response, error = _session().get(url, verify=False, timeout=10), None
        except Exception as e:
            response, error = None, e
    return response, error


# Regex to search and replace the sourceMappingURL
_SOURCE_MAP_RE = re.compile(
    r'(?m)((?://|/\*)[#@][ \t]*sourceMappingURL=)([^\s"\'*]+?)([ \t]*(?:\*/)?[ \t\r]*)$'
)

_SCHEME_RE = re.compile(r'^[a-z][a-z0-9+.-]*:', re.I)

# https://registry.npmjs.org/bootstrap/-/bootstrap-5.3.0-alpha1.tgz
_NPM_TARBALL_RE = re.compile(
    r'^https://registry\.npmjs\.org/(?P<package>(?:@[^/]+/)?[^/]+)/-/[^/]+-(?P<version>\d[^/]*)\.tgz$'
)


def _rewrite_source_map_url(content, base_url):
    """
    Repoints a bundled file's sourceMappingURL at its origin, or drops it.

    Sourcemaps are only ever read with devtools open, so bundling them adds
    ~9MB to the wheel that no deployment needs at runtime. Dropping the
    files while leaving the comment alone is not an option either: the
    browser then asks for a .map next to the bundled copy on every page
    load and gets a 404. Rewriting the comment to the url the file was
    fetched from keeps in-browser debugging working for anyone with network
    access, and keeps the console quiet for everyone else.

    ``base_url`` is None where a file came out of a tarball and there is no
    per-file url to resolve against, in which case the comment is removed.
    """
    def rewrite(match):
        prefix, url, suffix = match.groups()
        if _SCHEME_RE.match(url):
            # An inline data: uri carries the map itself, and an absolute
            # url already resolves independently of where the file sits.
            return match.group(0)
        if base_url is None:
            return ''
        return prefix + urljoin(base_url, url) + suffix
    return _SOURCE_MAP_RE.sub(rewrite, content)


def _npm_cdn_dir(tarball):
    """
    The npm CDN directory an extracted npm tarball corresponds to.

    Panel bundles a handful of libraries from the npm registry rather than
    from a CDN, which loses the per-file url ``_rewrite_source_map_url``
    needs. The registry url names the package and version, so for those the
    CDN directory can be reconstructed.
    """
    match = _NPM_TARBALL_RE.match(tarball.get('tar', ''))
    if match is None:
        return None
    src = tarball.get('src', '').removeprefix('package').strip('/')
    package = f"{match['package']}@{match['version']}"
    return '/'.join(part for part in (config.npm_cdn, package, src) if part) + '/'


def _unminified_duplicates(names):
    """
    Names that are shipped in both a minified and an unminified build.

    Panel only ever references the minified build, so the unminified copy is
    weight nothing loads: bootstrap, jQuery, font-awesome and reveal.js each
    publish a complete unminified duplicate of every file, which together is
    6MB of the wheel.
    """
    names = set(names)
    duplicates = set()
    for name in names:
        base, dot, ext = name.rpartition('.')
        if not dot or base.endswith('.min'):
            continue
        if f'{base}.min.{ext}' in names:
            duplicates.add(name)
    return duplicates


def _license_spec(url):
    """
    The npm release a bundled url was taken from.
    """
    npm_cdn = config.npm_cdn.rstrip('/') + '/'
    if url.startswith(npm_cdn):
        parts = url[len(npm_cdn):].split('/')
        return '/'.join(parts[:2]) if parts[0].startswith('@') else parts[0]
    tarball = _NPM_TARBALL_RE.match(url)
    if tarball:
        return f"{tarball['package']}@{tarball['version']}"
    for prefix, spec in LICENSE_PACKAGES.items():
        if url.startswith(prefix):
            return spec
    raise ValueError(
        f'Could not tell which package {url} belongs to, so the terms it is '
        'licensed under cannot be bundled alongside it. Add the npm release '
        'it corresponds to to panel.compiler.LICENSE_PACKAGES.'
    )


def _register_license(url):
    """
    Records that a url is being bundled, so its license travels with it.

    Panel redistributes some 50 third-party libraries inside its own wheel,
    which means it also has to redistribute the terms they are licensed
    under. The urls are the only complete record of what is bundled, so the
    license set is derived from them rather than from a separate list that a
    new dependency can be added without touching.
    """
    url = url.split('?')[0]
    if url.startswith(CDN_DIST):
        return
    _LICENSE_SOURCES.setdefault(_license_spec(url), set()).add(url)


def _write_license(spec, index):
    npm_cdn = config.npm_cdn.rstrip('/')
    response, error = _download(f'{npm_cdn}/{spec}/package.json')
    if error or not response.ok:
        msg = f'Failed to fetch package metadata for {spec}, cannot determine its license.'
        raise ConnectionError(msg) from error
    meta = json.loads(response.content)
    name, version = meta.get('name', spec), meta.get('version', '')
    spdx = meta.get('license')

    for license_name in LICENSE_NAMES:
        response, error = _download(f'{npm_cdn}/{spec}/{license_name}')
        if not error and response.ok:
            text, license_url = response.text, f'{npm_cdn}/{spec}/{license_name}'
            break
    else:
        if not spdx:
            msg = (
                f'{spec} publishes neither license text nor a license field in its '
                'package.json, so there is nothing to redistribute it under.'
            )
            raise ConnectionError(msg)
        # A published package is not required to include its license text, in
        # which case the identifier it declares is all there is to record.
        text = (
            f'{name} {version} is distributed under the {spdx} license.\n'
            'The published package contains no license text of its own.\n'
        )
        license_url = None

    filename = LICENSE_DIR / f'{name}@{version}.txt'
    filename.parent.mkdir(parents=True, exist_ok=True)
    filename.write_text(text, encoding='utf-8')
    index.append({
        'package': name,
        'version': version,
        'specifier': spec,
        'license': spdx,
        'source': license_url,
        'file': filename.relative_to(BUNDLE_DIR).as_posix(),
    })

#---------------------------------------------------------------------
# Public API
#---------------------------------------------------------------------

def write_bundled_files(name, files, explicit_dir=None, ext=None, download_list=None):
    for bundle_file in files:
        if bundle_file.startswith('http'):
            _register_license(bundle_file)
    if download_list is None:
        _write_bundled_files(name, files, explicit_dir=explicit_dir, ext=ext)
    else:
        download_list.append(partial(_write_bundled_files, name, files, explicit_dir=explicit_dir, ext=ext))

def _write_bundled_files(name, files, explicit_dir=None, ext=None):
    model_name = name.split('.')[-1].lower()
    for bundle_file in files:
        if not bundle_file.startswith('http'):
            dest_path = BUNDLE_DIR / name.lower() / bundle_file
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(BASE_DIR / 'theme' / bundle_file, dest_path)
            continue

        bundle_file = bundle_file.split('?')[0]

        # Resources pointing at Panel's own CDN (jQuery, Bootstrap and Font
        # Awesome, referenced by the designs and templates) are put in place by
        # bundle_resource_urls from npm, at the very path they resolve to.
        # Fetching them back from the CDN mirrors a second copy under
        # bundled/panel/<version>/dist/bundled/ that nothing ever serves, and
        # requires the version being built to already have been published.
        if bundle_file.startswith(CDN_DIST):
            continue

        response, error = _download(bundle_file)
        if error:
            msg =  f"Failed to fetch {name} dependency: {bundle_file}. Errored with {error}."
            raise ConnectionError(msg) from error
        if not response.ok:
            # A CDN answers a missing file with an error document and a 4xx
            # status, which written to disk becomes a library shaped like an
            # error message, e.g. perspective shipped a fonts.css containing
            # jsdelivr's "Couldn't find the requested file" for two releases.
            msg = f"Failed to fetch {name} dependency: {bundle_file}. Responded with status {response.status_code}."
            raise ConnectionError(msg)

        if bundle_file.startswith(config.npm_cdn):
            bundle_path = os.path.join(*bundle_file.replace(config.npm_cdn, '').split('/'))
        else:
            bundle_path = os.path.join(*os.path.join(*bundle_file.split('//')[1:]).split('/')[1:])
        obj_dir = explicit_dir or model_name
        filename = BUNDLE_DIR.joinpath(obj_dir, bundle_path)
        filename.parent.mkdir(parents=True, exist_ok=True)
        filename = str(filename)
        if ext and not str(filename).endswith(ext):
            filename += f'.{ext}'
        if filename.endswith(('.ttf', '.wasm', '.png', '.gif')):
            with open(filename, 'wb') as f:
                f.write(response.content)
        else:
            content = _rewrite_source_map_url(
                response.content.decode('utf-8'), bundle_file
            )
            with open(filename, 'w', encoding="utf-8") as f:
                f.write(content)

def write_bundled_tarball(tarball, name=None, module=False, download_list=None):
    _register_license(tarball['tar'])
    if download_list is None:
        _write_bundled_tarball(tarball, name=name, module=module)
    else:
        download_list.append(partial(_write_bundled_tarball, tarball, name=name, module=module))

def _write_bundled_tarball(tarball, name=None, module=False):
    model_name = name.split('.')[-1].lower() if name else ''
    response, error = _download(tarball['tar'])
    if error:
        raise error

    f = io.BytesIO()
    f.write(response.content)
    f.seek(0)
    tar_obj = tarfile.open(fileobj=f)
    exclude = tarball.get('exclude', [])
    cdn_dir = _npm_cdn_dir(tarball)
    for tarf in tar_obj:
        if not tarf.name.startswith(tarball['src']) or not tarf.isfile():
            continue
        path = tarf.name.replace(tarball['src'], '')
        if any(fnmatch.fnmatch(tarf.name, exc) for exc in exclude):
            continue
        if path.endswith('.map'):
            # Bootstrap ships its stylesheet maps inside the tarball, which
            # is 9MB of the wheel; the comments referring to them are
            # repointed at the CDN below.
            continue
        bundle_path = os.path.join(*path.split('/'))
        dest_path = tarball['dest'].replace('/', os.path.sep)
        if model_name:
            filename = BUNDLE_DIR.joinpath(model_name, dest_path, bundle_path)
        else:
            filename = BUNDLE_DIR.joinpath(dest_path, bundle_path)
        filename.parent.mkdir(parents=True, exist_ok=True)
        fobj = tar_obj.extractfile(tarf.name)
        filename = str(filename)
        if module and filename.endswith('.js'):
            filename = filename[:-3]
            if filename.endswith('index'):
                filename += '.mjs'
        if any(filename.endswith(ft) for ft in ('.ttf', '.eot', '.woff', '.woff2')):
            content = fobj.read()
            with open(filename, 'wb') as f:
                f.write(content)
        else:
            base_url = None if cdn_dir is None else urljoin(cdn_dir, path.lstrip('/'))
            content = _rewrite_source_map_url(fobj.read().decode('utf-8'), base_url)
            with open(filename, 'w', encoding="utf-8") as f:
                f.write(content)
    tar_obj.close()

def write_bundled_zip(name, resource, download_list=None):
    _register_license(resource['zip'])
    if download_list is None:
        _write_bundled_zip(name, resource)
    else:
        download_list.append(partial(_write_bundled_zip, name, resource))

def _write_bundled_zip(name, resource):
    response, error = _download(resource['zip'])
    if error:
        raise error

    f = io.BytesIO()
    f.write(response.content)
    f.seek(0)
    zip_obj = zipfile.ZipFile(f)
    exclude = resource.get('exclude', [])
    for zipf in zip_obj.namelist():
        path = zipf.replace(resource['src'], '')
        if any(fnmatch.fnmatch(zipf, exc) for exc in exclude) or zipf.endswith('/'):
            continue
        if path.endswith('.map'):
            continue
        bundle_path = path.replace('/', os.path.sep)
        filename = BUNDLE_DIR.joinpath(name, bundle_path)
        filename.parent.mkdir(parents=True, exist_ok=True)
        fdata = zip_obj.read(zipf)
        filename = str(filename)
        if any(filename.endswith(ft) for ft in ('.ttf', '.eot', '.woff', '.woff2')):
            with open(filename, 'wb') as f:
                f.write(fdata)
        else:
            # A zip carries no url per file, so a dangling comment is
            # stripped rather than repointed.
            content = _rewrite_source_map_url(fdata.decode('utf-8'), None)
            with open(filename, 'w', encoding="utf-8") as f:
                f.write(content)
    zip_obj.close()

def write_component_resources(name, component, download_list=None):
    write_bundled_files(name, list(component._resources.get('css', {}).values()), BUNDLE_DIR, 'css', download_list=download_list)
    write_bundled_files(name, list(component._resources.get('js', {}).values()), BUNDLE_DIR, 'js', download_list=download_list)
    js_modules = []
    for tar_name, js_module in component._resources.get('js_modules', {}).items():
        if tar_name not in component._resources.get('tarball', {}):
            js_modules.append(js_module)
    write_bundled_files(name, js_modules, 'js', ext='mjs', download_list=download_list)
    for tarball in component._resources.get('tarball', {}).values():
        write_bundled_tarball(tarball, download_list=download_list)

def bundle_resource_urls(verbose=False, external=True, download_list=None):
    # Collect shared resources
    for name, resource in RESOURCE_URLS.items():
        if verbose:
            print(f'Bundling shared resource {name}.')
        if 'zip' in resource:
            write_bundled_zip(name, resource, download_list=download_list)
        elif 'tar' in resource:
            write_bundled_tarball(resource, name=name, download_list=download_list)

def bundle_templates(verbose=False, external=True, download_list=None):
    # Bundle Template resources
    for template in _descendents(BasicTemplate, concrete=True):
        name = template.__name__
        if verbose:
            print(f'Bundling {name} resources')

        # Bundle Template._resources
        if template._resources.get('bundle', True) and external:
            write_component_resources(name, template, download_list=download_list)

        # Bundle CSS files in template dir
        template_dir = pathlib.Path(inspect.getfile(template)).parent
        dest_dir = BUNDLE_DIR / name.lower()
        dest_dir.mkdir(parents=True, exist_ok=True)
        for css in glob.glob(str(template_dir / '*.css')):
            shutil.copyfile(css, dest_dir / os.path.basename(css))

        # Bundle Template._css
        template_css = template._css
        if not isinstance(template_css, list):
            template_css = [template_css] if template_css else []
        for css in template_css:
            tmpl_name = name.lower()
            for cls in template.__mro__[1:]:
                if not issubclass(cls, BasicTemplate):
                    continue
                tmpl_css = cls._css if isinstance(cls._css, list) else [cls._css]
                if css in tmpl_css:
                    tmpl_name = cls.__name__.lower()
            tmpl_dest_dir = BUNDLE_DIR / tmpl_name
            tmpl_dest_dir.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(css, tmpl_dest_dir / os.path.basename(css))

        # Bundle Template._js
        template_js = template._js
        if not isinstance(template_js, list):
            template_js = [template_js] if template_js else []
        for js in template_js:
            tmpl_name = name.lower()
            for cls in template.__mro__[1:]:
                if not issubclass(cls, BasicTemplate):
                    continue
                tmpl_js = cls._js if isinstance(cls._js, list) else [cls._js]
                if js in tmpl_js:
                    tmpl_name = cls.__name__.lower()
            tmpl_dest_dir = BUNDLE_DIR / tmpl_name
            shutil.copyfile(js, tmpl_dest_dir / os.path.basename(js))

def bundle_themes(verbose=False, external=True, download_list=None):
    # Bundle design stylesheets
    for design in _descendents(Design, concrete=True):
        name = design.__name__
        if verbose:
            print(f'Bundling {name} design resources')

        # Bundle Design._resources
        if design._resources.get('bundle', True) and external:
            write_component_resources(name, design, download_list=download_list)

    theme_bundle_dir = BUNDLE_DIR / 'theme'
    theme_bundle_dir.mkdir(parents=True, exist_ok=True)
    for design_css in glob.glob(str(BASE_DIR / 'theme' / 'css' / '*.css')):
        shutil.copyfile(design_css, theme_bundle_dir / os.path.basename(design_css))

def bundle_models(verbose=False, external=True, download_list=None):
    for imp in panel_extension._imports.values():
        if imp.startswith('panel.models'):
            __import__(imp)

    if not external:
        return

    # Extract Model dependencies
    js_files, css_files, resource_files = {}, {}, {}
    reactive = _descendents(ReactiveHTML, concrete=True)
    models = (
        list(Model.model_class_reverse_map.items()) +
        [(f'{m.__module__}.{m.__name__}', m) for m in reactive]
    )
    for name, model in models:
        if not name.startswith('panel.'):
            continue
        if verbose:
            print(f'Collecting {name} resources')
        prev_jsfiles = (
            getattr(model, '__javascript_raw__', []) +
            getattr(model, '__javascript_modules_raw__', [])
        ) or None
        prev_jsbundle = getattr(model, '__tarball__', None)
        prev_cls = model
        for cls in model.__mro__[1:]:
            jsfiles = (
                getattr(cls, '__javascript_raw__', []) +
                getattr(cls, '__javascript_modules_raw__', [])
            ) or None
            if ((jsfiles is None and prev_jsfiles is not None) or
                (jsfiles is not None and jsfiles != prev_jsfiles)):
                if prev_jsbundle:
                    js_files[prev_cls.__name__] = prev_jsbundle
                else:
                    js_files[prev_cls.__name__] = prev_jsfiles
                break
            prev_cls = cls
        prev_cssfiles = getattr(model, '__css_raw__', None)
        prev_cls = model
        for cls in model.__mro__[1:]:
            cssfiles = getattr(cls, '__css_raw__', None)
            if ((cssfiles is None and prev_cssfiles is not None) or
                (cssfiles is not None and cssfiles != prev_cssfiles)):
                css_files[prev_cls.__name__] = prev_cssfiles
                break
            prev_cls = cls
        prev_resources = getattr(model, '__resources__', None)
        prev_cls = model
        for cls in model.__mro__[1:]:
            resources = getattr(cls, '__resources__', None)
            if ((resources is None and prev_resources is not None) or
                (resources is not None and resources != prev_resources)):
                resource_files[prev_cls.__name__] = prev_resources
                break
            prev_cls = cls

    # Bundle Model dependencies
    for name, jsfiles in js_files.items():
        if verbose:
            print(f'Bundling {name} model JS resources')
        if isinstance(jsfiles, dict):
            write_bundled_tarball(jsfiles, name=name, download_list=download_list)
        else:
            write_bundled_files(name, jsfiles, download_list=download_list)

    for name, cssfiles in css_files.items():
        if verbose:
            print(f'Bundling {name} model CSS resources')
        write_bundled_files(name, cssfiles, download_list=download_list)

    for name, res_files in resource_files.items():
        write_bundled_files(name, res_files, download_list=download_list)

def prune_unminified_duplicates(verbose=False):
    """
    Drops every bundled file that also has a minified build alongside it.

    Runs over the finished bundle rather than over each archive because the
    two builds do not always come from the same place: reveal.js publishes
    only ``reveal.css`` in its tarball, and Panel fetches ``reveal.min.css``
    from the CDN because that is the one the template asks for.
    """
    for directory in {path.parent for path in BUNDLE_DIR.rglob('*') if path.is_file()}:
        names = [path.name for path in directory.iterdir() if path.is_file()]
        for name in _unminified_duplicates(names):
            if verbose:
                print(f'Dropping unminified {(directory / name).relative_to(BUNDLE_DIR)}')
            (directory / name).unlink()

def bundle_licenses(verbose=False, download_list=None):
    """
    Bundles the license of every third-party library collected so far.

    Has to run after the other bundle_* functions, since the set of licenses
    is derived from the urls they collected.
    """
    index = []
    for spec in sorted(_LICENSE_SOURCES):
        if verbose:
            print(f'Bundling {spec} license')
        write = partial(_write_license, spec, index)
        if download_list is None:
            write()
        else:
            download_list.append(write)
    return index

def write_license_index(index):
    LICENSE_DIR.mkdir(parents=True, exist_ok=True)
    index = sorted(index, key=lambda entry: (entry['package'], entry['version']))
    (LICENSE_DIR / 'index.json').write_text(
        json.dumps(index, indent=2) + '\n', encoding='utf-8'
    )

def bundle_icons(verbose=False, external=True, download_list=None):
    # Bundle icons & images
    dest_dir = BUNDLE_DIR / 'images'
    dest_dir.mkdir(parents=True, exist_ok=True)
    icon_dir = pathlib.Path(__file__).parent.parent / 'doc' / '_static' / 'icons'
    for icon in glob.glob(str(icon_dir / '*')):
        shutil.copyfile(icon, dest_dir / os.path.basename(icon))

def patch_tabulator():
    path = BUNDLE_DIR / 'datatabulator' / f'tabulator-tables@{TABULATOR_VERSION}' / 'dist' / 'js' / 'tabulator.min.js'
    text = path.read_text()
    # https://github.com/olifolkerd/tabulator/issues/4421
    old = '"focus"!==this.options("editTriggerEvent")&&"click"!==this.options("editTriggerEvent")'
    new = '"click"!==this.options("editTriggerEvent")'
    assert text.count(old) == 1
    text = text.replace(old, new)
    path.write_text(text)

def bundle_resources(verbose=False, external=True):
    download_list = []
    _LICENSE_SOURCES.clear()
    bundle_resource_urls(verbose=verbose, external=external, download_list=download_list)
    bundle_models(verbose=verbose, external=external, download_list=download_list)
    bundle_templates(verbose=verbose, external=external, download_list=download_list)
    bundle_themes(verbose=verbose, external=external, download_list=download_list)
    bundle_icons(verbose=verbose, external=external, download_list=download_list)
    licenses = bundle_licenses(verbose=verbose, download_list=download_list) if external else []

    with ThreadPoolExecutor() as executor:
        futures = executor.map(lambda x: x(), download_list)

    # Check for exceptions
    for future in futures:
        if future:
            future.result()

    if licenses:
        write_license_index(licenses)

    prune_unminified_duplicates(verbose=verbose)
    patch_tabulator()
